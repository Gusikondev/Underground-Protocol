class_name Beer
extends RigidBody3D
# Бутылка пива: физический проп. Можно пнуть, выстрелить (разбивается), взорвать.

var broken: bool = false

func _mi(mesh: Mesh, col: Color, pos: Vector3) -> void:
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	var m := StandardMaterial3D.new()
	m.albedo_color = col
	mi.material_override = m
	mi.position = pos
	add_child(mi)

func build() -> void:
	add_to_group("beer")
	collision_layer = 2
	collision_mask = 5
	mass = 0.6
	var cs := CollisionShape3D.new()
	var sh := CylinderShape3D.new()
	sh.radius = 0.045
	sh.height = 0.28
	cs.shape = sh
	add_child(cs)
	var amber := Color(0.42, 0.22, 0.04)
	var body := CylinderMesh.new()
	body.top_radius = 0.042
	body.bottom_radius = 0.042
	body.height = 0.17
	_mi(body, amber, Vector3(0, -0.055, 0))
	var neck := CylinderMesh.new()
	neck.top_radius = 0.016
	neck.bottom_radius = 0.04
	neck.height = 0.09
	_mi(neck, amber, Vector3(0, 0.074, 0))
	var cap := CylinderMesh.new()
	cap.top_radius = 0.019
	cap.bottom_radius = 0.019
	cap.height = 0.012
	_mi(cap, Color(0.85, 0.7, 0.15), Vector3(0, 0.125, 0))
	var label := CylinderMesh.new()
	label.top_radius = 0.0435
	label.bottom_radius = 0.0435
	label.height = 0.07
	_mi(label, Color(0.93, 0.88, 0.7), Vector3(0, -0.05, 0))

func smash() -> void:
	if broken:
		return
	broken = true
	var p := get_parent()
	Fx.burst(p, global_position, Color(0.9, 0.7, 0.15), 18, 2.5, 0.02, 0.8)   # пиво
	Fx.burst(p, global_position, Color(0.55, 0.75, 0.6), 14, 3.5, 0.015, 1.0) # стекло
	queue_free()
