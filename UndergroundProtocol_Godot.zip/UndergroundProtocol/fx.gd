class_name Fx
extends RefCounted
# Мелкие помощники: статичный бокс и взрыв частиц

static func box(parent: Node, size: Vector3, pos: Vector3, color: Color) -> StaticBody3D:
	var b := StaticBody3D.new()
	b.collision_layer = 1
	b.collision_mask = 0
	var cs := CollisionShape3D.new()
	var sh := BoxShape3D.new()
	sh.size = size
	cs.shape = sh
	b.add_child(cs)
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	mi.material_override = m
	b.add_child(mi)
	parent.add_child(b)
	b.position = pos
	return b

static func burst(parent: Node, pos: Vector3, color: Color, amount: int, speed: float, size: float, life: float) -> void:
	var p := CPUParticles3D.new()
	var sm := SphereMesh.new()
	sm.radius = size
	sm.height = size * 2.0
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	sm.material = m
	p.mesh = sm
	p.amount = amount
	p.one_shot = true
	p.explosiveness = 1.0
	p.lifetime = life
	p.direction = Vector3.UP
	p.spread = 180.0
	p.initial_velocity_min = speed * 0.4
	p.initial_velocity_max = speed
	p.gravity = Vector3(0, -9.8, 0)
	parent.add_child(p)
	p.global_position = pos
	p.emitting = true
	parent.get_tree().create_timer(life + 0.5).timeout.connect(p.queue_free)

static var _ai: AudioStream = null

static func scream(parent: Node, pos: Vector3) -> void:
	if _ai == null and ResourceLoader.exists("res://assets/audio/Ai.mp3"):
		_ai = load("res://assets/audio/Ai.mp3") as AudioStream
	if _ai == null or parent == null:
		return
	var p := AudioStreamPlayer3D.new()
	p.stream = _ai
	p.pitch_scale = randf_range(0.9, 1.2)
	p.unit_size = 15.0
	parent.add_child(p)
	p.global_position = pos
	p.finished.connect(p.queue_free)
	p.play()

static var _tex: Dictionary = {}

static func tex(path: String) -> Texture2D:
	if not _tex.has(path):
		_tex[path] = load(path) if ResourceLoader.exists(path) else null
	return _tex[path] as Texture2D

# Картинка взрыва (Bum) + вспышка света
static func explosion(parent: Node, pos: Vector3, size: float) -> void:
	if parent == null or not parent.is_inside_tree():
		return
	var t := tex("res://assets/fx/bum.png")
	if t != null:
		var s := Sprite3D.new()
		s.texture = t
		s.billboard = BaseMaterial3D.BILLBOARD_ENABLED
		s.shaded = false
		s.double_sided = true
		s.pixel_size = size / float(t.get_width())
		parent.add_child(s)
		s.global_position = pos + Vector3(0, size * 0.25, 0)
		s.scale = Vector3.ONE * 0.3
		var tw := s.create_tween().set_parallel(true)
		tw.tween_property(s, "scale", Vector3.ONE * 1.1, 0.6)
		tw.tween_property(s, "modulate:a", 0.0, 0.7).set_delay(0.2)
		parent.get_tree().create_timer(1.0).timeout.connect(s.queue_free)
	var l := OmniLight3D.new()
	l.light_color = Color(1.0, 0.6, 0.2)
	l.omni_range = size * 1.5
	l.light_energy = 6.0
	parent.add_child(l)
	l.global_position = pos + Vector3(0, 1.0, 0)
	l.create_tween().tween_property(l, "light_energy", 0.0, 0.4)
	parent.get_tree().create_timer(0.5).timeout.connect(l.queue_free)

# Струя крови из оторванной части (secs секунд)
static func bleed(rb: Node3D, secs: float, lpos: Vector3 = Vector3.ZERO, strong: bool = false) -> void:
	if Cfg.gore == 0 or rb == null or not rb.is_inside_tree():
		return
	var p := CPUParticles3D.new()
	var sm := SphereMesh.new()
	sm.radius = 0.03
	sm.height = 0.06
	var m := StandardMaterial3D.new()
	m.albedo_color = Color(0.67, 0.0, 0.06)
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	sm.material = m
	p.mesh = sm
	p.amount = 40 if strong else 22
	p.lifetime = 0.6
	p.local_coords = false
	p.direction = Vector3.UP
	p.spread = 35.0
	p.initial_velocity_min = 4.0 if strong else 2.0
	p.initial_velocity_max = 7.0 if strong else 4.0
	p.gravity = Vector3(0, -9.8, 0)
	p.position = lpos
	rb.add_child(p)
	p.emitting = true
	rb.get_tree().create_timer(secs).timeout.connect(func():
		if is_instance_valid(p):
			p.emitting = false)
	rb.get_tree().create_timer(secs + 1.0).timeout.connect(func():
		if is_instance_valid(p):
			p.queue_free())
