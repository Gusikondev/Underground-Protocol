class_name Drone
extends CharacterBody3D
# Камикадзе-дрон: пропеллеры, зелёный заряд РПГ-7 снизу, камера от первого лица

signal exploded(pos)

var cam: Camera3D
var rotors: Array = []
var pitch: float = 0.0
var vy: float = 0.0
var dead: bool = false

func _mat(c: Color, a: float = 1.0) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = Color(c.r, c.g, c.b, a)
	if a < 1.0:
		m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	return m

func _add(mesh: Mesh, mat: Material, pos: Vector3, rot: Vector3 = Vector3.ZERO, parent: Node3D = null) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.material_override = mat
	mi.position = pos
	mi.rotation = rot
	(parent if parent != null else self).add_child(mi)
	return mi

func build() -> void:
	collision_layer = 0
	collision_mask = 51
	var cs := CollisionShape3D.new()
	var sh := SphereShape3D.new()
	sh.radius = 0.3
	cs.shape = sh
	add_child(cs)
	var dark := _mat(Color(0.1, 0.1, 0.11))
	var green := _mat(Color(0.25, 0.5, 0.16))
	var tip := _mat(Color(0.18, 0.35, 0.11))
	var bm := BoxMesh.new()
	bm.size = Vector3(0.5, 0.12, 0.5)
	_add(bm, dark, Vector3.ZERO)
	# 4 пропеллера (два передних видны из камеры)
	for c in [Vector2(-0.32, -0.28), Vector2(0.32, -0.28), Vector2(-0.32, 0.3), Vector2(0.32, 0.3)]:
		var r := Node3D.new()
		r.position = Vector3(c.x, 0.1, c.y)
		add_child(r)
		var b1 := BoxMesh.new()
		b1.size = Vector3(0.5, 0.012, 0.06)
		_add(b1, dark, Vector3.ZERO, Vector3.ZERO, r)
		_add(b1, dark, Vector3.ZERO, Vector3(0, PI / 2.0, 0), r)
		var disc := CylinderMesh.new()
		disc.top_radius = 0.27
		disc.bottom_radius = 0.27
		disc.height = 0.004
		_add(disc, _mat(Color(1, 1, 1), 0.15), Vector3.ZERO, Vector3.ZERO, r)
		rotors.append(r)
	# заряд РПГ-7 снизу (просто зелёный)
	var cyl := CylinderMesh.new()
	cyl.top_radius = 0.06
	cyl.bottom_radius = 0.06
	cyl.height = 0.5
	_add(cyl, green, Vector3(0, -0.2, -0.3), Vector3(PI / 2.0, 0, 0))
	var cone := CylinderMesh.new()
	cone.top_radius = 0.0
	cone.bottom_radius = 0.06
	cone.height = 0.18
	_add(cone, tip, Vector3(0, -0.2, -0.64), Vector3(-PI / 2.0, 0, 0))
	cam = Camera3D.new()
	cam.fov = 80.0
	cam.near = 0.03
	cam.position = Vector3(0, 0.07, 0.12)
	add_child(cam)

func _process(delta: float) -> void:
	for r in rotors:
		(r as Node3D).rotate_y(45.0 * delta)

func drive(inp: Vector2, vert: float, yaw: float, delta: float) -> void:
	if dead:
		return
	# вперёд -> камера вниз, назад -> камера вверх
	pitch = lerpf(pitch, -inp.y * 0.6, minf(1.0, 3.0 * delta))
	rotation = Vector3(pitch, yaw, 0.0)
	var fwd := Vector3(-sin(yaw), 0.0, -cos(yaw))
	var right := Vector3(cos(yaw), 0.0, -sin(yaw))
	vy = move_toward(vy, vert * 4.0, 5.0 * delta)   # плавный вверх/вниз
	var v := fwd * inp.y * 12.0 + right * inp.x * 7.0 + Vector3(0.0, vy, 0.0)
	var c := move_and_collide(v * delta)
	if c != null or global_position.y < 0.3:
		explode()

func explode() -> void:
	if dead:
		return
	dead = true
	exploded.emit(global_position)
	queue_free()
