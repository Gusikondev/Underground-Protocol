class_name Weather
extends Node3D
# Динамическая погода: дождь (авто / ясно / дождь из настроек)

var env: Environment
var sky0: Color
var fog0: float = 0.01
var rain: CPUParticles3D
var target: float = 0.0
var intensity: float = 0.0
var timer: float = 40.0

func setup(e: Environment, sky: Color, fog: float) -> void:
	env = e
	sky0 = sky
	fog0 = fog
	rain = CPUParticles3D.new()
	var bm := BoxMesh.new()
	bm.size = Vector3(0.012, 0.6, 0.012)
	var m := StandardMaterial3D.new()
	m.albedo_color = Color(0.75, 0.85, 1.0, 0.5)
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	bm.material = m
	rain.mesh = bm
	rain.amount = 700
	rain.lifetime = 0.7
	rain.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
	rain.emission_box_extents = Vector3(18, 0.5, 18)
	rain.direction = Vector3(0.1, -1, 0)
	rain.spread = 2.0
	rain.gravity = Vector3(0, -30, 0)
	rain.initial_velocity_min = 22.0
	rain.initial_velocity_max = 28.0
	rain.local_coords = false
	rain.emitting = false
	add_child(rain)

func raining() -> bool:
	return intensity > 0.4

func update(delta: float, center: Vector3) -> void:
	rain.global_position = center + Vector3(0, 14, 0)
	if Cfg.weather == 1:
		target = 0.0
	elif Cfg.weather == 2:
		target = 1.0
	else:
		timer -= delta
		if timer <= 0.0:
			timer = randf_range(45.0, 100.0)
			target = 1.0 if target < 0.5 and randf() < 0.6 else 0.0
	intensity = move_toward(intensity, target, delta * 0.2)
	rain.emitting = intensity > 0.05
	if env != null:
		env.background_color = sky0.lerp(Color(0.38, 0.4, 0.43), intensity * 0.8)
		env.fog_light_color = env.background_color
		env.fog_density = fog0 + intensity * 0.012
		env.ambient_light_energy = lerpf(0.9, 0.55, intensity)
