class_name TrafficCar
extends AnimatableBody3D
# Машина городского трафика: едет по своей полосе туда-обратно по кругу, сбивает людей

var axis_x: bool = true
var dir: float = 1.0
var speed: float = 10.0
var line: float = 0.0
var lane: float = 3.0
const LIM := 68.0

func _b(size: Vector3, pos: Vector3, col: Color) -> void:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	var m := StandardMaterial3D.new()
	m.albedo_color = col
	mi.material_override = m
	mi.position = pos
	add_child(mi)

func setup(ax_x: bool, ln: float, d: float, sp: float, start: float) -> void:
	collision_layer = 64
	collision_mask = 0
	sync_to_physics = true
	add_to_group("traffic")
	axis_x = ax_x
	line = ln
	dir = d
	speed = sp
	lane = 3.0 * (d if ax_x else -d)
	var cs := CollisionShape3D.new()
	var sh := BoxShape3D.new()
	sh.size = Vector3(1.9, 1.1, 4.3)
	cs.shape = sh
	cs.position = Vector3(0, 0.8, 0)
	add_child(cs)
	var paint := Color.from_hsv(randf(), 0.6, 0.7)
	_b(Vector3(1.9, 0.65, 4.3), Vector3(0, 0.72, 0), paint)
	_b(Vector3(1.6, 0.6, 2.2), Vector3(0, 1.3, 0.15), paint)
	_b(Vector3(1.62, 0.4, 2.0), Vector3(0, 1.33, 0.15), Color(0.08, 0.1, 0.13))
	for sx in [-0.95, 0.95]:
		for sz in [-1.35, 1.35]:
			_b(Vector3(0.3, 0.76, 0.76), Vector3(sx, 0.38, sz), Color(0.06, 0.06, 0.07))
	_b(Vector3(0.4, 0.15, 0.08), Vector3(-0.6, 0.85, -2.15), Color(1, 0.95, 0.7))
	_b(Vector3(0.4, 0.15, 0.08), Vector3(0.6, 0.85, -2.15), Color(1, 0.95, 0.7))
	_place(start)

func _place(a: float) -> void:
	if axis_x:
		global_position = Vector3(a, 0, line + lane)
		rotation.y = -PI / 2.0 if dir > 0.0 else PI / 2.0
	else:
		global_position = Vector3(line + lane, 0, a)
		rotation.y = PI if dir > 0.0 else 0.0

func _physics_process(delta: float) -> void:
	var a := (global_position.x if axis_x else global_position.z) + dir * speed * delta
	if a > LIM:
		a = -LIM
	elif a < -LIM:
		a = LIM
	_place(a)
	var inv := global_transform.affine_inverse()
	for h in get_tree().get_nodes_in_group("humans"):
		var rel: Vector3 = inv * (h as Node3D).global_position
		if absf(rel.x) < 1.3 and absf(rel.z) < 2.6 and (h as Human).dead == false:
			(h as Human).die(-global_transform.basis.z * speed * 0.3 + Vector3.UP * 2.0)
