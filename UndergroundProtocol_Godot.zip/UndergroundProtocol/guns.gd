class_name Guns
extends RefCounted
# Процедурные модели оружия (без Sketchfab): ствол смотрит в -Z, магазин виден сбоку.

static func _mat(c: Color, glow: bool = false) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.roughness = 0.55
	if glow:
		m.emission_enabled = true
		m.emission = c
		m.emission_energy_multiplier = 2.5
	return m

static func box(p: Node3D, size: Vector3, pos: Vector3, c: Color, rot: Vector3 = Vector3.ZERO, glow: bool = false) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var b := BoxMesh.new()
	b.size = size
	mi.mesh = b
	mi.material_override = _mat(c, glow)
	mi.position = pos
	mi.rotation = rot
	p.add_child(mi)
	return mi

# цилиндр вдоль оси Z
static func cyl(p: Node3D, r: float, l: float, pos: Vector3, c: Color, glow: bool = false) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var m := CylinderMesh.new()
	m.top_radius = r
	m.bottom_radius = r
	m.height = l
	mi.mesh = m
	mi.material_override = _mat(c, glow)
	mi.position = pos
	mi.rotation = Vector3(PI / 2.0, 0, 0)
	p.add_child(mi)
	return mi

static func _pistol(g: Node3D) -> Dictionary:
	var dark := Color(0.1, 0.1, 0.11)
	var mid := Color(0.2, 0.2, 0.22)
	box(g, Vector3(0.032, 0.034, 0.19), Vector3(0, 0.03, -0.02), dark)
	box(g, Vector3(0.03, 0.018, 0.17), Vector3(0, 0.005, -0.01), mid)
	cyl(g, 0.009, 0.04, Vector3(0, 0.03, -0.13), Color(0.3, 0.3, 0.32))
	box(g, Vector3(0.028, 0.085, 0.04), Vector3(0, -0.04, 0.06), mid, Vector3(0.22, 0, 0))
	box(g, Vector3(0.026, 0.03, 0.036), Vector3(0, -0.098, 0.078), dark, Vector3(0.22, 0, 0))
	box(g, Vector3(0.006, 0.025, 0.05), Vector3(0, -0.015, 0.0), dark)
	box(g, Vector3(0.006, 0.015, 0.006), Vector3(0, 0.054, -0.1), dark)
	box(g, Vector3(0.012, 0.012, 0.008), Vector3(0, 0.053, 0.07), dark)
	box(g, Vector3(0.004, 0.014, 0.04), Vector3(0.017, 0.036, -0.01), Color(0.02, 0.02, 0.02))
	return {"muzzle": Vector3(0, 0.03, -0.15), "top": Vector3(0, 0.05, 0.0), "grip": Vector3(0, -0.05, 0.07), "fore": Vector3(0, -0.02, -0.04)}

static func _ak(g: Node3D) -> Dictionary:
	var steel := Color(0.28, 0.28, 0.3)
	var dark := Color(0.14, 0.14, 0.15)
	var wood := Color(0.45, 0.25, 0.1)
	box(g, Vector3(0.05, 0.065, 0.32), Vector3(0, 0, 0.02), dark)
	box(g, Vector3(0.044, 0.02, 0.3), Vector3(0, 0.04, 0.02), Color(0.11, 0.11, 0.12))
	box(g, Vector3(0.056, 0.05, 0.26), Vector3(0, -0.005, -0.27), wood)
	box(g, Vector3(0.05, 0.02, 0.26), Vector3(0, 0.03, -0.27), Color(0.35, 0.19, 0.08))
	cyl(g, 0.01, 0.3, Vector3(0, 0.02, -0.58), steel)
	cyl(g, 0.012, 0.22, Vector3(0, 0.05, -0.3), steel)
	box(g, Vector3(0.012, 0.045, 0.02), Vector3(0, 0.045, -0.7), dark)
	box(g, Vector3(0.004, 0.02, 0.004), Vector3(0, 0.075, -0.7), dark)
	cyl(g, 0.014, 0.05, Vector3(0, 0.02, -0.75), dark)
	box(g, Vector3(0.02, 0.012, 0.02), Vector3(0, 0.052, -0.05), dark)
	for i in 5:
		box(g, Vector3(0.032, 0.05, 0.055), Vector3(0, -0.06 - i * 0.042, -0.05 - 0.006 * i * i), Color(0.17, 0.17, 0.18), Vector3(0.1 * i, 0, 0))
	box(g, Vector3(0.035, 0.1, 0.05), Vector3(0, -0.08, 0.16), Color(0.12, 0.08, 0.05), Vector3(0.35, 0, 0))
	box(g, Vector3(0.006, 0.03, 0.09), Vector3(0, -0.045, 0.07), dark)
	box(g, Vector3(0.04, 0.1, 0.26), Vector3(0, -0.01, 0.38), wood, Vector3(-0.12, 0, 0))
	box(g, Vector3(0.042, 0.11, 0.02), Vector3(0, -0.02, 0.52), dark)
	box(g, Vector3(0.01, 0.015, 0.04), Vector3(0.032, 0.02, 0.0), steel)
	return {"muzzle": Vector3(0, 0.02, -0.78), "top": Vector3(0, 0.065, 0.0), "grip": Vector3(0, -0.1, 0.17), "fore": Vector3(0, -0.04, -0.28)}

static func _shotgun(g: Node3D) -> Dictionary:
	var steel := Color(0.22, 0.22, 0.24)
	var wood := Color(0.4, 0.22, 0.1)
	cyl(g, 0.014, 0.62, Vector3(0, 0.02, -0.45), steel)
	cyl(g, 0.013, 0.5, Vector3(0, -0.012, -0.4), steel)
	box(g, Vector3(0.05, 0.045, 0.17), Vector3(0, -0.012, -0.35), wood)
	box(g, Vector3(0.048, 0.075, 0.25), Vector3(0, 0, -0.02), Color(0.13, 0.13, 0.14))
	box(g, Vector3(0.003, 0.02, 0.07), Vector3(0.025, -0.02, 0.0), Color(0.02, 0.02, 0.02))
	box(g, Vector3(0.004, 0.015, 0.004), Vector3(0, 0.04, -0.75), Color(0.9, 0.8, 0.3))
	box(g, Vector3(0.006, 0.03, 0.08), Vector3(0, -0.05, 0.05), Color(0.1, 0.1, 0.11))
	box(g, Vector3(0.04, 0.09, 0.3), Vector3(0, -0.02, 0.28), wood, Vector3(-0.2, 0, 0))
	box(g, Vector3(0.042, 0.1, 0.02), Vector3(0, -0.05, 0.43), Color(0.08, 0.08, 0.08))
	box(g, Vector3(0.035, 0.08, 0.05), Vector3(0, -0.065, 0.12), wood, Vector3(0.3, 0, 0))
	for i in 4:
		box(g, Vector3(0.01, 0.014, 0.03), Vector3(-0.026, 0.012, -0.08 + i * 0.045), Color(0.8, 0.1, 0.1))
	return {"muzzle": Vector3(0, 0.02, -0.78), "top": Vector3(0, 0.045, 0.0), "grip": Vector3(0, -0.07, 0.12), "fore": Vector3(0, -0.04, -0.35)}

static func _smg(g: Node3D) -> Dictionary:
	var dark := Color(0.12, 0.12, 0.13)
	var steel := Color(0.28, 0.28, 0.3)
	box(g, Vector3(0.045, 0.06, 0.26), Vector3(0, 0.0, -0.02), dark)
	box(g, Vector3(0.04, 0.015, 0.24), Vector3(0, 0.035, -0.02), steel)
	cyl(g, 0.009, 0.14, Vector3(0, 0.012, -0.22), steel)
	box(g, Vector3(0.03, 0.12, 0.045), Vector3(0, -0.085, 0.05), dark, Vector3(0.12, 0, 0))
	box(g, Vector3(0.026, 0.14, 0.04), Vector3(0, -0.1, -0.06), steel, Vector3(0.0, 0, 0))
	box(g, Vector3(0.008, 0.012, 0.22), Vector3(0, 0.0, 0.22), steel)
	box(g, Vector3(0.008, 0.05, 0.01), Vector3(0, -0.02, 0.33), steel)
	box(g, Vector3(0.006, 0.012, 0.006), Vector3(0, 0.045, -0.2), dark)
	return {"muzzle": Vector3(0, 0.012, -0.3), "top": Vector3(0, 0.043, 0.0), "grip": Vector3(0, -0.1, 0.05), "fore": Vector3(0, -0.07, -0.08)}

static func _sniper(g: Node3D) -> Dictionary:
	var steel := Color(0.2, 0.2, 0.22)
	var wood := Color(0.35, 0.2, 0.1)
	box(g, Vector3(0.05, 0.07, 0.3), Vector3(0, 0, -0.02), Color(0.13, 0.13, 0.14))
	cyl(g, 0.012, 0.6, Vector3(0, 0.015, -0.5), steel)
	box(g, Vector3(0.05, 0.04, 0.22), Vector3(0, -0.012, -0.3), wood)
	box(g, Vector3(0.045, 0.1, 0.34), Vector3(0, -0.03, 0.32), wood, Vector3(-0.1, 0, 0))
	box(g, Vector3(0.03, 0.09, 0.045), Vector3(0, -0.07, 0.1), wood, Vector3(0.25, 0, 0))
	box(g, Vector3(0.012, 0.012, 0.05), Vector3(0.035, 0.02, 0.02), steel)
	cyl(g, 0.022, 0.26, Vector3(0, 0.085, -0.05), Color(0.08, 0.08, 0.09))
	cyl(g, 0.03, 0.05, Vector3(0, 0.085, -0.19), Color(0.08, 0.08, 0.09))
	cyl(g, 0.02, 0.012, Vector3(0, 0.085, 0.085), Color(0.4, 0.7, 1.0), true)
	box(g, Vector3(0.012, 0.03, 0.03), Vector3(0, 0.05, -0.12), steel)
	box(g, Vector3(0.012, 0.03, 0.03), Vector3(0, 0.05, 0.03), steel)
	return {"muzzle": Vector3(0, 0.015, -0.82), "top": Vector3(0, 0.085, 0.0), "grip": Vector3(0, -0.09, 0.1), "fore": Vector3(0, -0.04, -0.3)}

static func _revolver(g: Node3D) -> Dictionary:
	var steel := Color(0.3, 0.3, 0.33)
	var wood := Color(0.4, 0.22, 0.1)
	box(g, Vector3(0.03, 0.05, 0.12), Vector3(0, 0.0, 0.0), steel)
	cyl(g, 0.011, 0.2, Vector3(0, 0.025, -0.15), steel)
	cyl(g, 0.03, 0.06, Vector3(0, 0.015, -0.02), Color(0.22, 0.22, 0.24))
	box(g, Vector3(0.032, 0.1, 0.045), Vector3(0, -0.06, 0.07), wood, Vector3(0.25, 0, 0))
	box(g, Vector3(0.012, 0.03, 0.03), Vector3(0, 0.04, 0.065), steel, Vector3(-0.4, 0, 0))
	box(g, Vector3(0.006, 0.014, 0.006), Vector3(0, 0.055, -0.24), steel)
	box(g, Vector3(0.006, 0.02, 0.05), Vector3(0, -0.035, 0.0), steel)
	return {"muzzle": Vector3(0, 0.025, -0.26), "top": Vector3(0, 0.055, 0.0), "grip": Vector3(0, -0.05, 0.075), "fore": Vector3(0, -0.02, -0.04)}

static func _rpg(g: Node3D) -> Dictionary:
	var olive := Color(0.3, 0.36, 0.2)
	var dark := Color(0.1, 0.1, 0.11)
	cyl(g, 0.045, 0.9, Vector3(0, 0.03, -0.1), olive)
	cyl(g, 0.065, 0.14, Vector3(0, 0.03, -0.62), Color(0.35, 0.4, 0.18))
	cyl(g, 0.01, 0.1, Vector3(0, 0.03, -0.74), Color(0.25, 0.25, 0.27))
	cyl(g, 0.06, 0.1, Vector3(0, 0.03, 0.4), dark)
	box(g, Vector3(0.02, 0.05, 0.05), Vector3(0, 0.095, -0.02), dark)
	box(g, Vector3(0.006, 0.03, 0.006), Vector3(0, 0.1, -0.45), dark)
	box(g, Vector3(0.03, 0.1, 0.04), Vector3(0, -0.06, -0.16), dark)
	box(g, Vector3(0.035, 0.1, 0.05), Vector3(0, -0.07, 0.12), dark, Vector3(0.3, 0, 0))
	return {"muzzle": Vector3(0, 0.03, -0.8), "top": Vector3(0, 0.1, -0.02), "grip": Vector3(0, -0.06, 0.12), "fore": Vector3(0, -0.04, -0.16)}

static func _fists() -> Dictionary:
	var root := Node3D.new()
	var skin := Color(0.88, 0.69, 0.5)
	var sleeve := Color(0.15, 0.17, 0.2)
	var out := {"root": root, "muzzle": Vector3.ZERO}
	for side in ["fl", "fr"]:
		var sx := -0.13 if side == "fl" else 0.13
		var n := Node3D.new()
		root.add_child(n)
		box(n, Vector3(0.095, 0.085, 0.11), Vector3(sx, -0.17, -0.38), skin)
		for k in 4:
			box(n, Vector3(0.02, 0.02, 0.02), Vector3(sx - 0.036 + k * 0.024, -0.14, -0.44), Color(0.8, 0.6, 0.45))
		box(n, Vector3(0.09, 0.09, 0.5), Vector3(sx * 1.3, -0.26, -0.08), sleeve, Vector3(-0.28, 0.0, 0.0))
		out[side] = n
	return out

static func _chainsaw(g: Node3D) -> Dictionary:
	var orange := Color(0.95, 0.45, 0.08)
	var dark := Color(0.1, 0.1, 0.11)
	var steel := Color(0.6, 0.6, 0.64)
	box(g, Vector3(0.075, 0.11, 0.24), Vector3(0, 0.0, 0.05), orange)
	box(g, Vector3(0.03, 0.04, 0.14), Vector3(0, 0.08, 0.1), dark)
	box(g, Vector3(0.03, 0.1, 0.05), Vector3(0, -0.07, 0.15), dark, Vector3(0.3, 0, 0))
	box(g, Vector3(0.03, 0.075, 0.56), Vector3(0, 0.0, -0.36), Color(0.3, 0.3, 0.33))
	box(g, Vector3(0.036, 0.085, 0.58), Vector3(0, 0.0, -0.36), dark)
	for i in 12:
		box(g, Vector3(0.042, 0.012, 0.03), Vector3(0, 0.046, -0.1 - i * 0.045), steel)
		box(g, Vector3(0.042, 0.012, 0.03), Vector3(0, -0.046, -0.1 - i * 0.045 - 0.02), steel)
	box(g, Vector3(0.05, 0.06, 0.04), Vector3(0, 0.0, -0.1), Color(0.8, 0.8, 0.82))
	return {"muzzle": Vector3(0, 0.0, -0.66), "top": Vector3(0, 0.1, 0.1), "grip": Vector3(0, -0.07, 0.15), "fore": Vector3(0, 0.08, 0.1)}

static func _grav(g: Node3D) -> Dictionary:
	var orange := Color(0.9, 0.45, 0.1)
	cyl(g, 0.04, 0.28, Vector3(0, 0, -0.05), Color(0.1, 0.1, 0.12))
	cyl(g, 0.05, 0.12, Vector3(0, 0, 0.1), orange)
	cyl(g, 0.055, 0.03, Vector3(0, 0, -0.2), orange)
	box(g, Vector3(0.01, 0.01, 0.15), Vector3(-0.03, 0, -0.28), Color(0.4, 0.4, 0.42), Vector3(0, 0.1, 0))
	box(g, Vector3(0.01, 0.01, 0.15), Vector3(0.03, 0, -0.28), Color(0.4, 0.4, 0.42), Vector3(0, -0.1, 0))
	cyl(g, 0.02, 0.18, Vector3(0, 0, -0.14), Color(0.3, 0.7, 1.0), true)
	var tip := MeshInstance3D.new()
	var s := SphereMesh.new()
	s.radius = 0.03
	s.height = 0.06
	tip.mesh = s
	tip.material_override = _mat(Color(0.4, 0.8, 1.0), true)
	tip.position = Vector3(0, 0, -0.3)
	g.add_child(tip)
	box(g, Vector3(0.035, 0.1, 0.05), Vector3(0, -0.08, 0.06), Color(0.1, 0.1, 0.12), Vector3(0.3, 0, 0))
	return {"muzzle": Vector3(0, 0, -0.35), "top": Vector3(0, 0.06, 0.05), "grip": Vector3(0, -0.1, 0.07), "fore": Vector3(0, -0.03, -0.02)}

static func _hands(root: Node3D, d: Dictionary) -> void:
	var skin := Color(0.88, 0.69, 0.5)
	var sleeve := Color(0.15, 0.17, 0.2)
	var gp: Vector3 = d["grip"]
	var fo: Vector3 = d["fore"]
	box(root, Vector3(0.075, 0.09, 0.085), gp + Vector3(0, 0.02, 0), skin)
	box(root, Vector3(0.02, 0.02, 0.05), gp + Vector3(-0.045, 0.03, -0.01), skin)
	for i in 3:
		box(root, Vector3(0.07, 0.02, 0.025), gp + Vector3(0, 0.0 - i * 0.022, -0.05), skin)
	box(root, Vector3(0.085, 0.085, 0.5), gp + Vector3(0.05, -0.12, 0.28), sleeve, Vector3(-0.35, 0.1, 0))
	box(root, Vector3(0.07, 0.05, 0.1), fo, skin)
	box(root, Vector3(0.02, 0.02, 0.05), fo + Vector3(0.04, 0.02, 0.0), skin)
	box(root, Vector3(0.08, 0.08, 0.5), fo + Vector3(-0.06, -0.12, 0.3), sleeve, Vector3(-0.3, -0.2, 0))

static func _attachments(root: Node3D, d: Dictionary, out: Dictionary) -> void:
	var top: Vector3 = d["top"]
	var mz: Vector3 = d["muzzle"]
	var scope := Node3D.new()
	scope.position = top
	box(scope, Vector3(0.03, 0.012, 0.07), Vector3(0, 0.006, 0), Color(0.1, 0.1, 0.11))
	box(scope, Vector3(0.004, 0.035, 0.05), Vector3(-0.013, 0.03, 0), Color(0.1, 0.1, 0.11))
	box(scope, Vector3(0.004, 0.035, 0.05), Vector3(0.013, 0.03, 0), Color(0.1, 0.1, 0.11))
	box(scope, Vector3(0.026, 0.004, 0.05), Vector3(0, 0.05, 0), Color(0.1, 0.1, 0.11))
	box(scope, Vector3(0.022, 0.028, 0.002), Vector3(0, 0.03, -0.02), Color(0.5, 0.8, 1.0))
	box(scope, Vector3(0.004, 0.004, 0.004), Vector3(0, 0.03, -0.019), Color(1, 0.1, 0.1), Vector3.ZERO, true)
	scope.visible = false
	root.add_child(scope)
	var supp := Node3D.new()
	supp.position = mz + Vector3(0, 0, -0.085)
	cyl(supp, 0.021, 0.17, Vector3.ZERO, Color(0.06, 0.06, 0.07))
	cyl(supp, 0.023, 0.012, Vector3(0, 0, -0.08), Color(0.2, 0.2, 0.22))
	supp.visible = false
	root.add_child(supp)
	var laser := Node3D.new()
	laser.position = mz + Vector3(0.03, -0.02, 0.1)
	box(laser, Vector3(0.018, 0.018, 0.04), Vector3.ZERO, Color(0.1, 0.1, 0.11))
	box(laser, Vector3(0.002, 0.002, 14.0), Vector3(0, 0, -7.0), Color(1.0, 0.05, 0.05), Vector3.ZERO, true)
	laser.visible = false
	root.add_child(laser)
	out["scope"] = scope
	out["supp"] = supp
	out["laser"] = laser

# kind: pistol / ak / shotgun / grav. Возвращает {"root","muzzle","scope","supp","laser"}
static func build(kind: String) -> Dictionary:
	if kind == "fists":
		return _fists()
	var root := Node3D.new()
	var d: Dictionary
	match kind:
		"pistol":
			d = _pistol(root)
		"ak":
			d = _ak(root)
		"shotgun":
			d = _shotgun(root)
		"chainsaw":
			d = _chainsaw(root)
		"smg":
			d = _smg(root)
		"sniper":
			d = _sniper(root)
		"revolver":
			d = _revolver(root)
		"rpg":
			d = _rpg(root)
		_:
			d = _grav(root)
	_hands(root, d)
	var out := {"root": root, "muzzle": d["muzzle"]}
	# позиция при прицеливании: мушка/планка оказывается на линии взгляда (в центре экрана)
	var tp: Vector3 = d["top"]
	out["aim"] = Vector3(-tp.x, -(tp.y + 0.014), -0.3 - tp.z)
	out["aim_s"] = Vector3(-tp.x, -(tp.y + 0.034), -0.3 - tp.z)
	if kind != "grav":
		_attachments(root, d, out)
	return out
