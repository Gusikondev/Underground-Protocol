class_name Barrel
extends RigidBody3D
# Бочка. Красная взрывается от выстрела, удара и других взрывов.

signal exploded(pos)

var explosive: bool = true
var done: bool = false

func build(expl: bool) -> void:
	explosive = expl
	add_to_group("barrels")
	collision_layer = 1
	collision_mask = 1 | 4 | 16
	mass = 30.0
	var cs := CollisionShape3D.new()
	var sh := CylinderShape3D.new()
	sh.radius = 0.3
	sh.height = 0.9
	cs.shape = sh
	add_child(cs)
	var mi := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = 0.3
	cm.bottom_radius = 0.3
	cm.height = 0.9
	mi.mesh = cm
	var m := StandardMaterial3D.new()
	m.albedo_color = Color(0.75, 0.1, 0.08) if expl else Color(0.45, 0.28, 0.16)
	mi.material_override = m
	add_child(mi)
	for y in [-0.25, 0.25]:
		var ring := MeshInstance3D.new()
		var rm := CylinderMesh.new()
		rm.top_radius = 0.31
		rm.bottom_radius = 0.31
		rm.height = 0.05
		ring.mesh = rm
		var rmat := StandardMaterial3D.new()
		rmat.albedo_color = Color(0.15, 0.15, 0.15)
		ring.material_override = rmat
		ring.position = Vector3(0, y, 0)
		add_child(ring)

func explode(delay: float = 0.0) -> void:
	if done or not explosive:
		return
	done = true
	if delay > 0.0:
		await get_tree().create_timer(delay).timeout
	if not is_inside_tree():
		return
	exploded.emit(global_position)
	Fx.burst(get_parent(), global_position, Color(1.0, 0.55, 0.0), 60, 9.0, 0.12, 0.8)
	Fx.explosion(get_parent(), global_position, 5.0)
	Fx.burst(get_parent(), global_position, Color(0.2, 0.2, 0.2), 30, 5.0, 0.2, 1.2)
	queue_free()
