class_name BrickWall
extends Node3D
# Кирпичная стена из отдельных кирпичей. Рассыпается от машины, взрыва, выстрела.

var bricks: Array = []
var released: bool = false

func build(cols: int, rows: int, along_x: bool) -> void:
	add_to_group("brickwalls")
	for r in rows:
		for c in cols:
			var rb := RigidBody3D.new()
			rb.collision_layer = 1
			rb.collision_mask = 1 | 4 | 16
			rb.mass = 2.0
			rb.add_to_group("bricks")
			var cs := CollisionShape3D.new()
			var sh := BoxShape3D.new()
			sh.size = Vector3(0.8, 0.35, 0.4)
			cs.shape = sh
			rb.add_child(cs)
			var mi := MeshInstance3D.new()
			var bm := BoxMesh.new()
			bm.size = Vector3(0.8, 0.35, 0.4)
			mi.mesh = bm
			var m := StandardMaterial3D.new()
			var k := randf_range(-0.05, 0.05)
			m.albedo_color = Color(0.6 + k, 0.25 + k * 0.5, 0.18)
			mi.material_override = m
			rb.add_child(mi)
			var off := (c - (cols - 1) / 2.0) * 0.82 + (0.4 if r % 2 == 1 else 0.0)
			rb.position = Vector3(off, 0.18 + r * 0.36, 0) if along_x else Vector3(0, 0.18 + r * 0.36, off)
			if not along_x:
				rb.rotation.y = PI / 2.0
			rb.freeze = true
			rb.freeze_mode = RigidBody3D.FREEZE_MODE_STATIC
			add_child(rb)
			bricks.append(rb)

func release(from: Vector3, impulse: Vector3) -> void:
	if released:
		return
	released = true
	for b in bricks:
		if is_instance_valid(b):
			var rb := b as RigidBody3D
			rb.freeze = false
			var away := (rb.global_position - from)
			away.y = 0.0
			rb.apply_central_impulse(impulse * 0.12 + away.normalized() * randf_range(1.0, 3.0) + Vector3(0, randf() * 1.5, 0))

func break_near(pos: Vector3, r: float, impulse: Vector3 = Vector3.ZERO) -> void:
	if released:
		return
	for b in bricks:
		if is_instance_valid(b) and (b as Node3D).global_position.distance_to(pos) < r:
			release(pos, impulse + (global_position - pos).normalized() * -8.0)
			return

# машина подъезжает быстро -> стена рассыпается
func car_near(pos: Vector3, v: Vector3) -> void:
	if released or v.length() < 6.0:
		return
	if global_position.distance_to(pos) < 4.8:
		release(pos, v)
