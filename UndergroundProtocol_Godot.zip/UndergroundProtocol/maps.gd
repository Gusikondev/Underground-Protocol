class_name Maps
extends RefCounted
# Карты: 0 Полигон, 1 Пустынный аванпост, 2 Сектор Ноль (заброшенный завод)

const NAMES := ["Полигон", "Пустынный аванпост", "Сектор Ноль", "Дрифт-трек", "Город"]

static func _barrel(g: Node3D, pos: Vector3, expl: bool) -> void:
	var b := Barrel.new()
	b.build(expl)
	g.add_child(b)
	b.global_position = pos + Vector3(0, 0.46, 0)
	b.exploded.connect(Callable(g, "_blast").bind(6.0))

static func _brick(g: Node3D, pos: Vector3, cols: int, rows: int, along_x: bool) -> void:
	var w := BrickWall.new()
	w.build(cols, rows, along_x)
	g.add_child(w)
	w.global_position = pos

static func _pipe(g: Node3D, pos: Vector3, length: float, r: float, yaw: float) -> void:
	var b := StaticBody3D.new()
	b.collision_layer = 1
	var cs := CollisionShape3D.new()
	var sh := CylinderShape3D.new()
	sh.radius = r
	sh.height = length
	cs.shape = sh
	cs.rotation = Vector3(PI / 2.0, 0, 0)
	b.add_child(cs)
	var mi := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = r
	cm.bottom_radius = r
	cm.height = length
	mi.mesh = cm
	var m := StandardMaterial3D.new()
	m.albedo_color = Color(0.35, 0.25, 0.2)
	mi.material_override = m
	mi.rotation = Vector3(PI / 2.0, 0, 0)
	b.add_child(mi)
	g.add_child(b)
	b.position = pos + Vector3(0, r, 0)
	b.rotation.y = yaw

# стена с оконными проёмами (1.6 x 1.4 м) или дверным проёмом
static func _wall(g: Node3D, c: Vector3, L: float, h: float, axis: String, n_win: int, door_w: float) -> void:
	var t := 0.5
	var col := Color(0.42, 0.43, 0.45)
	var seg := func(off: float, l: float, y0: float, y1: float) -> void:
		var size := Vector3(l, y1 - y0, t) if axis == "x" else Vector3(t, y1 - y0, l)
		var pos := c + (Vector3(off, 0, 0) if axis == "x" else Vector3(0, 0, off)) + Vector3(0, (y0 + y1) / 2.0, 0)
		Fx.box(g, size, pos, col)
	if door_w > 0.0:
		var dl := (L - door_w) / 2.0
		seg.call(-L / 2.0 + dl / 2.0, dl, 0.0, h)
		seg.call(L / 2.0 - dl / 2.0, dl, 0.0, h)
		seg.call(0.0, door_w, 4.6, h)
		return
	var cur := -L / 2.0
	if n_win > 0:
		var s := L / n_win
		for i in n_win:
			var wc := -L / 2.0 + s * (i + 0.5)
			var ws := wc - 0.8
			seg.call(cur + (ws - cur) / 2.0, ws - cur, 0.0, h)
			seg.call(wc, 1.6, 0.0, 2.0)
			seg.call(wc, 1.6, 3.4, h)
			cur = wc + 0.8
	seg.call(cur + (L / 2.0 - cur) / 2.0, L / 2.0 - cur, 0.0, h)

static func _hangar(g: Node3D, c: Vector3, w: float, d: float, h: float) -> void:
	_wall(g, Vector3(c.x, 0, c.z + d / 2.0), w, h, "x", 0, 5.0)
	_wall(g, Vector3(c.x, 0, c.z - d / 2.0), w, h, "x", 0, 0.0)
	_wall(g, Vector3(c.x - w / 2.0, 0, c.z), d, h, "z", 4, 0.0)
	_wall(g, Vector3(c.x + w / 2.0, 0, c.z), d, h, "z", 4, 0.0)
	Fx.box(g, Vector3(w + 1.0, 0.5, d + 1.0), Vector3(c.x, h + 0.25, c.z), Color(0.3, 0.3, 0.32))

static func _border(g: Node3D, half: float, h: float, col: Color) -> void:
	Fx.box(g, Vector3(half * 2.0 + 2.0, h, 1), Vector3(0, h / 2.0, -half - 0.5), col)
	Fx.box(g, Vector3(half * 2.0 + 2.0, h, 1), Vector3(0, h / 2.0, half + 0.5), col)
	Fx.box(g, Vector3(1, h, half * 2.0 + 2.0), Vector3(-half - 0.5, h / 2.0, 0), col)
	Fx.box(g, Vector3(1, h, half * 2.0 + 2.0), Vector3(half + 0.5, h / 2.0, 0), col)

static func build(g: Node3D, id: int) -> Dictionary:
	match id:
		1:
			return _desert(g)
		2:
			return _factory(g)
		3:
			return _drift(g)
		4:
			return _city(g)
		_:
			return _polygon(g)

static func _polygon(g: Node3D) -> Dictionary:
	Fx.box(g, Vector3(100, 1, 100), Vector3(0, -0.5, 0), Color(0.55, 0.55, 0.53))
	_border(g, 40.0, 6.0, Color(0.35, 0.35, 0.37))
	var rng := RandomNumberGenerator.new()
	rng.seed = 7
	for i in 12:
		var x := rng.randf_range(-34, 34)
		var z := rng.randf_range(-34, 34)
		if Vector2(x, z - 10).length() < 7.0:
			continue
		var sz := Vector3(rng.randf_range(2, 7), rng.randf_range(2, 4), rng.randf_range(2, 7))
		Fx.box(g, sz, Vector3(x, sz.y / 2.0, z), Color(0.47, 0.46, 0.42))
	_barrel(g, Vector3(6, 0, 4), true)
	_barrel(g, Vector3(-8, 0, 2), false)
	return {"bound": 40.0, "sky": Color(0.62, 0.77, 0.91), "fog": 0.004, "mud": [], "road_mat": null,
		"spawn": Vector3(0, 0, 10), "humans": [Vector3(-8, 0, -4), Vector3(5, 0, -8), Vector3(10, 0, 0), Vector3(-3, 0, -12)]}

static func _desert(g: Node3D) -> Dictionary:
	Fx.box(g, Vector3(320, 1, 320), Vector3(0, -0.5, 0), Color(0.86, 0.74, 0.5))
	_border(g, 150.0, 5.0, Color(0.8, 0.68, 0.45))
	var road := MeshInstance3D.new()
	var pm := PlaneMesh.new()
	pm.size = Vector2(8, 300)
	road.mesh = pm
	var rm := StandardMaterial3D.new()
	rm.albedo_color = Color(0.4, 0.29, 0.18)
	road.material_override = rm
	g.add_child(road)
	road.position = Vector3(18, 0.03, 0)
	var rust := Color(0.5, 0.28, 0.15)
	for p in [Vector3(-25, 0, -10), Vector3(-18, 0, -28), Vector3(30, 0, -40)]:
		var tr := Node3D.new()
		g.add_child(tr)
		tr.position = p
		tr.rotation.y = randf_range(0.0, PI)
		Fx.box(tr, Vector3(2.6, 2.7, 7.5), Vector3(0, 1.35, 0), rust)
		Fx.box(tr, Vector3(2.8, 0.2, 7.7), Vector3(0, 2.8, 0), Color(0.62, 0.6, 0.55))
		Fx.box(tr, Vector3(1.0, 1.9, 0.1), Vector3(0, 1.0, 3.8), Color(0.2, 0.15, 0.1))
	var wreck := Node3D.new()
	g.add_child(wreck)
	wreck.position = Vector3(-45, 0, 20)
	wreck.rotation.y = 0.4
	Fx.box(wreck, Vector3(2.5, 0.9, 7.5), Vector3(0, 0.7, 0), Color(0.3, 0.2, 0.14))
	Fx.box(wreck, Vector3(2.5, 1.9, 2.4), Vector3(0, 1.9, -2.6), Color(0.45, 0.25, 0.13))
	Fx.box(wreck, Vector3(2.3, 0.4, 4.0), Vector3(0, 1.3, 1.6), Color(0.25, 0.17, 0.12))
	var tw := Node3D.new()
	g.add_child(tw)
	tw.position = Vector3(40, 0, -60)
	for sx in [-3.0, 3.0]:
		for sz in [-3.0, 3.0]:
			Fx.box(tw, Vector3(0.5, 12, 0.5), Vector3(sx, 6, sz), Color(0.35, 0.32, 0.3))
	Fx.box(tw, Vector3(8, 0.4, 8), Vector3(0, 12, 0), Color(0.4, 0.37, 0.34))
	Fx.box(tw, Vector3(5, 2.6, 5), Vector3(0, 13.5, 0), Color(0.5, 0.3, 0.2))
	Fx.box(tw, Vector3(5.6, 0.3, 5.6), Vector3(0, 15, 0), Color(0.3, 0.28, 0.26))
	var ramp := Fx.box(g, Vector3(6, 0.4, 10), Vector3(0, 0.9, -30), Color(0.5, 0.45, 0.4))
	ramp.rotation.x = 0.2
	for p in [Vector3(-30, 0, -5), Vector3(-22, 0, 2), Vector3(35, 0, -30)]:
		_barrel(g, p, false)
	for p in [Vector3(-21, 0, -22), Vector3(27, 0, -36), Vector3(-43, 0, 15)]:
		_barrel(g, p, true)
	for i in 10:
		var s := Vector3(randf_range(1.5, 4.0), randf_range(1.0, 2.5), randf_range(1.5, 4.0))
		Fx.box(g, s, Vector3(randf_range(-120, 120), s.y / 2.0, randf_range(-120, 120)), Color(0.6, 0.5, 0.35))
	return {"bound": 150.0, "sky": Color(0.75, 0.82, 0.9), "fog": 0.002, "mud": [Rect2(14, -150, 8, 300)], "road_mat": rm,
		"spawn": Vector3(5, 0, 40), "humans": [Vector3(-22, 0, -5), Vector3(-10, 0, -20), Vector3(8, 0, -5), Vector3(25, 0, -30)]}

static func _factory(g: Node3D) -> Dictionary:
	Fx.box(g, Vector3(130, 1, 130), Vector3(0, -0.5, 0), Color(0.3, 0.3, 0.32))
	_border(g, 55.0, 9.0, Color(0.28, 0.28, 0.3))
	_hangar(g, Vector3(-25, 0, -15), 24.0, 30.0, 8.0)
	_hangar(g, Vector3(26, 0, -22), 22.0, 20.0, 7.0)
	for i in 5:
		Fx.box(g, Vector3(1.5, 1.5, 3.0), Vector3(-8 + i * 1.6, 0.75, 22), Color(0.55, 0.55, 0.56))
	Fx.box(g, Vector3(3, 3, 3), Vector3(15, 1.5, 15), Color(0.5, 0.5, 0.52))
	Fx.box(g, Vector3(3, 3, 3), Vector3(-30, 1.5, 28), Color(0.5, 0.5, 0.52))
	_brick(g, Vector3(0, 0, 10), 7, 8, true)
	_brick(g, Vector3(-40, 0, 25), 7, 8, false)
	_brick(g, Vector3(10, 0, -45), 7, 8, true)
	for i in 5:
		_pipe(g, Vector3(-5 + i * 2.2, 0, -5), 12.0, 0.35, 0.0)
	_pipe(g, Vector3(35, 0, 12), 14.0, 0.45, PI / 2.0)
	var spots := [Vector3(-30, 0, -20), Vector3(-31, 0, -19), Vector3(-30, 0, -18), Vector3(22, 0, -24), Vector3(24, 0, -25), Vector3(-12, 0, 20), Vector3(-13, 0, 21)]
	for i in spots.size():
		_barrel(g, spots[i], i % 2 == 0)
	return {"bound": 55.0, "sky": Color(0.32, 0.34, 0.38), "fog": 0.012, "mud": [], "road_mat": null,
		"spawn": Vector3(0, 0, 45), "humans": [Vector3(-5, 0, 5), Vector3(12, 0, 10), Vector3(-15, 0, 25), Vector3(20, 0, 30)]}

# плоская полоска без коллизии (линии, бордюры)
static func _strip(g: Node3D, size: Vector3, pos: Vector3, col: Color, yaw: float = 0.0) -> void:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	var mt := StandardMaterial3D.new()
	mt.albedo_color = col
	mi.material_override = mt
	g.add_child(mi)
	mi.position = pos
	mi.rotation.y = yaw

static func _drift(g: Node3D) -> Dictionary:
	Fx.box(g, Vector3(150, 1, 150), Vector3(0, -0.5, 0), Color(0.16, 0.16, 0.18))
	_border(g, 62.0, 2.0, Color(0.85, 0.85, 0.88))
	# центральный остров (трасса по кругу вокруг него)
	Fx.box(g, Vector3(66, 1.2, 66), Vector3(0, 0.6, 0), Color(0.25, 0.5, 0.22))
	# красно-белые бордюры вдоль острова
	for i in 8:
		var c := Color(0.9, 0.1, 0.1) if i % 2 == 0 else Color(0.95, 0.95, 0.95)
		var a := -29.0 + i * 8.0
		_strip(g, Vector3(8, 0.05, 0.8), Vector3(a, 1.25, 33.4), c)
		_strip(g, Vector3(8, 0.05, 0.8), Vector3(a, 1.25, -33.4), c)
		_strip(g, Vector3(0.8, 0.05, 8), Vector3(33.4, 1.25, a), c)
		_strip(g, Vector3(0.8, 0.05, 8), Vector3(-33.4, 1.25, a), c)
	# стартовая линия
	_strip(g, Vector3(29, 0.03, 1.5), Vector3(0, 0.03, 48.0), Color(0.95, 0.95, 0.95))
	# шины по углам внешнего борта
	for p in [Vector3(-58, 0, -58), Vector3(58, 0, -58), Vector3(-58, 0, 58), Vector3(58, 0, 58), Vector3(-58, 0, 0), Vector3(58, 0, 0), Vector3(0, 0, -58)]:
		for k in 3:
			Fx.box(g, Vector3(1.4, 0.9, 1.4), p + Vector3(k * 1.5 - 1.5, 0.45, 0), Color(0.05, 0.05, 0.05) if k != 1 else Color(0.8, 0.1, 0.1))
	return {"bound": 62.0, "sky": Color(0.55, 0.7, 0.88), "fog": 0.003, "mud": [], "road_mat": null,
		"spawn": Vector3(0, 0, 52), "humans": [Vector3(-55, 0, 20), Vector3(55, 0, -20), Vector3(0, 0, -55), Vector3(25, 0, -55), Vector3(-30, 0, 55), Vector3(55, 0, 40)]}

static func _city(g: Node3D) -> Dictionary:
	Fx.box(g, Vector3(160, 1, 160), Vector3(0, -0.5, 0), Color(0.2, 0.2, 0.22))
	_border(g, 66.0, 6.0, Color(0.35, 0.35, 0.38))
	var cs := [-40.0, 0.0, 40.0]
	var rng := RandomNumberGenerator.new()
	rng.seed = 11
	var humans: Array = []
	for bx in cs:
		for bz in cs:
			_strip(g, Vector3(30, 0.03, 30), Vector3(bx, 0.03, bz), Color(0.55, 0.55, 0.57))
			if bx == 0.0 and bz == 0.0:
				_strip(g, Vector3(26, 0.04, 26), Vector3(0, 0.05, 0), Color(0.25, 0.5, 0.22))
				for k in 4:
					Fx.box(g, Vector3(2.4, 0.5, 0.6), Vector3(-6 + k * 4.0, 0.25, -5), Color(0.4, 0.25, 0.1))
				humans.append(Vector3(0, 0.5, 4))
				humans.append(Vector3(-6, 0.5, 8))
				continue
			for i in 2:
				var d := rng.randf_range(14.0, 24.0)
				var h := rng.randf_range(8.0, 26.0)
				var col := Color.from_hsv(rng.randf(), 0.15, rng.randf_range(0.45, 0.8))
				Fx.box(g, Vector3(12, h, d), Vector3(bx - 7.0 + i * 14.0, h / 2.0, bz + rng.randf_range(-3.0, 3.0)), col)
			humans.append(Vector3(bx + 14, 0.5, bz + 14))
	# разметка дорог и трафик
	var lines := [-60.0, -20.0, 20.0, 60.0]
	for ln in lines:
		_strip(g, Vector3(132, 0.03, 0.3), Vector3(0, 0.05, ln), Color(0.9, 0.8, 0.2))
		_strip(g, Vector3(0.3, 0.03, 132), Vector3(ln, 0.05, 0), Color(0.9, 0.8, 0.2))
		for d in [1.0, -1.0]:
			var tx := TrafficCar.new()
			tx.setup(true, ln, d, rng.randf_range(8.0, 13.0), rng.randf_range(-60.0, 60.0))
			g.add_child(tx)
			var tz := TrafficCar.new()
			tz.setup(false, ln, d, rng.randf_range(8.0, 13.0), rng.randf_range(-60.0, 60.0))
			g.add_child(tz)
	# пешеходы на дорогах
	humans.append(Vector3(-20, 0.5, 5))
	humans.append(Vector3(20, 0.5, -10))
	return {"bound": 66.0, "sky": Color(0.7, 0.78, 0.88), "fog": 0.004, "mud": [], "road_mat": null,
		"spawn": Vector3(0, 0, 20), "humans": humans}
