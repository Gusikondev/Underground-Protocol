class_name Human
extends CharacterBody3D
# Человечек из кубов: ходит, убегает, умирает рэгдоллом (RigidBody3D + PinJoint3D)

signal died(h)

var hp: float = 100.0
var spin: bool = false      # крутится на месте (меню)
var ai: bool = false        # бродит и убегает (игра)
var dead: bool = false
var flee_t: float = 0.0
var threat: Vector3 = Vector3.ZERO
var wander_t: float = 0.0
var target: Vector3 = Vector3.ZERO
var swing: float = 0.0
var parts: Array = []
static var bound: float = 38.0
var flee_on_stand: bool = true
var piv: Dictionary = {}
var limb_hp: Dictionary = {"la": 90.0, "ra": 90.0, "ll": 90.0, "rl": 90.0}
var severed: Dictionary = {}
var bleed_out: float = 0.0
var grabbed: bool = false
var shake: float = 0.0
var fling: Vector3 = Vector3.ZERO
var fling_t: float = 0.0
var pending_fall: bool = false
var hold_zone: String = ""
var downed: bool = false
var down_t: float = 0.0
var scream_cd: float = 0.0
var drip_t: float = 0.0
var wall_cd: float = 0.0
var bleed_puddle: MeshInstance3D = null
const SCREAM_PATH := "res://assets/audio/Ai.mp3"
static var scream_stream: AudioStream = null
var torso_rb: RigidBody3D = null

# имя, размер, позиция, точка сустава (в локальных координатах человека)
const DEFS := [
	["torso", Vector3(0.5, 0.7, 0.25), Vector3(0, 1.05, 0), Vector3(0, 1.05, 0)],
	["head", Vector3(0.4, 0.4, 0.4), Vector3(0, 1.6, 0), Vector3(0, 1.4, 0)],
	["la", Vector3(0.18, 0.65, 0.18), Vector3(-0.36, 1.05, 0), Vector3(-0.36, 1.37, 0)],
	["ra", Vector3(0.18, 0.65, 0.18), Vector3(0.36, 1.05, 0), Vector3(0.36, 1.37, 0)],
	["ll", Vector3(0.22, 0.7, 0.22), Vector3(-0.14, 0.35, 0), Vector3(-0.14, 0.7, 0)],
	["rl", Vector3(0.22, 0.7, 0.22), Vector3(0.14, 0.35, 0), Vector3(0.14, 0.7, 0)],
]

func setup(shirt: Color) -> void:
	collision_layer = 2
	collision_mask = 1
	add_to_group("humans")
	var cs := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = 0.3
	cap.height = 1.8
	cs.shape = cap
	cs.position = Vector3(0, 0.9, 0)
	add_child(cs)
	var skin := Color(0.88, 0.69, 0.5)
	var pants := Color(0.16, 0.2, 0.31)
	for d in DEFS:
		var mi := MeshInstance3D.new()
		var bm := BoxMesh.new()
		bm.size = d[1]
		mi.mesh = bm
		var m := StandardMaterial3D.new()
		var n: String = d[0]
		if n == "head":
			m.albedo_color = skin
		elif n == "ll" or n == "rl":
			m.albedo_color = pants
		else:
			m.albedo_color = shirt
		mi.material_override = m
		if n == "la" or n == "ra" or n == "ll" or n == "rl":
			var pv := Node3D.new()
			pv.position = d[3]
			add_child(pv)
			mi.position = (d[2] as Vector3) - (d[3] as Vector3)
			pv.add_child(mi)
			piv[n] = pv
		else:
			mi.position = d[2]
			add_child(mi)
		if n == "head":
			for sx in [-0.1, 0.1]:
				var eye := MeshInstance3D.new()
				var eb := BoxMesh.new()
				eb.size = Vector3(0.07, 0.07, 0.02)
				eye.mesh = eb
				var em := StandardMaterial3D.new()
				em.albedo_color = Color(0.05, 0.05, 0.05)
				eye.material_override = em
				eye.position = Vector3(sx, 0.05, 0.2)
				mi.add_child(eye)
		parts.append({"mi": mi, "name": n, "size": d[1], "joint": d[3]})

func scream() -> void:
	if scream_cd > 0.0:
		return
	scream_cd = 0.5
	if scream_stream == null and ResourceLoader.exists(SCREAM_PATH):
		scream_stream = load(SCREAM_PATH)
	if scream_stream == null or get_parent() == null:
		return
	var p := AudioStreamPlayer3D.new()
	p.stream = scream_stream
	p.pitch_scale = randf_range(0.85, 1.25)
	p.unit_size = 12.0
	get_parent().add_child(p)
	p.global_position = global_position + Vector3(0, 1.5, 0)
	p.finished.connect(p.queue_free)
	p.play()

func hit(dmg: float, dir: Vector3, pt: Vector3 = Vector3.INF, gib: bool = false, sever: float = 1.0) -> void:
	if dead:
		return
	if pt.is_finite():
		var lp := to_local(pt)
		if lp.y > 1.4:
			hold_zone = "head"
		elif lp.y > 0.78:
			hold_zone = "torso"
		else:
			hold_zone = "legl" if lp.x < 0.0 else "legr"
	var limb := ""
	if pt.is_finite():
		limb = _limb_at(to_local(pt))
	if limb != "":
		hp -= dmg * 0.5
		if Cfg.gore == 2 and sever > 0.0 and not severed.has(limb):
			limb_hp[limb] = float(limb_hp[limb]) - dmg * sever
			if float(limb_hp[limb]) <= 0.0:
				sever_limb(limb, dir)
	else:
		hp -= dmg
	flee_t = 6.0
	scream()
	if hp <= 0.0:
		die(dir, gib)
		return
	if Cfg.gore > 0:
		Fx.burst(get_parent(), global_position + Vector3(0, 1.2, 0), Color(0.67, 0.0, 0.06), 6 if Cfg.gore == 1 else 14, 3.0, 0.03, 0.8)
	if not downed and hp < 45.0 and randf() < 0.5:
		fall(5.0 + randf() * 4.0)

# Пинок: сбивает с ног, но не убивает сразу
func knock(dir: Vector3) -> void:
	if dead:
		return
	fall(5.0, false)

func fall(t: float, flee_after: bool = true) -> void:
	flee_on_stand = flee_after
	if downed:
		down_t = maxf(down_t, t)
		return
	downed = true
	down_t = t
	var tw := create_tween().set_parallel(true)
	tw.tween_property(self, "rotation:x", -PI / 2.0, 0.35)
	tw.tween_property(self, "position:y", 0.18, 0.35)
	if Cfg.gore > 0 and hp < 100.0:
		bleed_puddle = Blood.puddle(get_parent(), global_position, 1.0, t)

func stand() -> void:
	downed = false
	flee_t = 5.0 if flee_on_stand else 0.0
	var tw := create_tween().set_parallel(true)
	tw.tween_property(self, "rotation:x", 0.0, 0.5)
	tw.tween_property(self, "position:y", 0.0, 0.5)

func _red_mat() -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = Color(0.55, 0.0, 0.05)
	return m

func _cap(size: Vector3, pos: Vector3) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	mi.material_override = _red_mat()
	mi.position = pos
	return mi

# Кишки: цепочка капсул на шарнирах, свисает из живота
func _guts(w: Node, torso: RigidBody3D, gx: Transform3D) -> void:
	var prev: RigidBody3D = torso
	var pos := gx * Vector3(0, 0.95, 0.16)
	for i in 8:
		var rb := RigidBody3D.new()
		rb.collision_layer = 4
		rb.collision_mask = 1
		rb.mass = 0.15
		w.add_child(rb)
		rb.global_position = pos + Vector3(0, -0.1 * i, 0.03 * i)
		var cs := CollisionShape3D.new()
		var sh := CapsuleShape3D.new()
		sh.radius = 0.045
		sh.height = 0.14
		cs.shape = sh
		rb.add_child(cs)
		var mi := MeshInstance3D.new()
		var cm := CapsuleMesh.new()
		cm.radius = 0.045
		cm.height = 0.14
		mi.mesh = cm
		var m := StandardMaterial3D.new()
		m.albedo_color = Color(0.8, 0.3, 0.36) if i % 2 == 0 else Color(0.65, 0.2, 0.28)
		mi.material_override = m
		rb.add_child(mi)
		var j := PinJoint3D.new()
		w.add_child(j)
		j.global_position = rb.global_position + Vector3(0, 0.07, 0)
		j.node_a = prev.get_path()
		j.node_b = rb.get_path()
		rb.apply_central_impulse(Vector3(randf() - 0.5, 0.2, randf() - 0.5) * 0.4)
		w.get_tree().create_timer(20.0).timeout.connect(rb.queue_free)
		w.get_tree().create_timer(20.0).timeout.connect(j.queue_free)
		prev = rb

# gib = true: взрыв, бензопила и т.п. (части отлетают всегда)
# какая конечность ближе всего к точке попадания (в локальных координатах)
func _limb_at(lp: Vector3) -> String:
	var best := ""
	var bd := 1.0e9
	for d in DEFS:
		var c := d[2] as Vector3
		var s := (d[1] as Vector3) * 0.5
		var q := Vector3((lp.x - c.x) / s.x, (lp.y - c.y) / s.y, (lp.z - c.z) / s.z)
		var dist := q.length_squared()
		if dist < bd:
			bd = dist
			best = d[0]
	return best if best in ["la", "ra", "ll", "rl"] else ""

# Конечность оторвана, человек жив: течёт кровь, без ноги он уже не встанет
func sever_limb(nm: String, dir: Vector3) -> void:
	if severed.has(nm) or dead:
		return
	severed[nm] = true
	var w := get_parent()
	var p: Dictionary = {}
	for q in parts:
		if q["name"] == nm:
			p = q
	var mi := p["mi"] as MeshInstance3D
	var sz := p["size"] as Vector3
	var rb := RigidBody3D.new()
	rb.collision_layer = 4
	rb.collision_mask = 1 | 4 | 163
	rb.mass = 1.0
	w.add_child(rb)
	rb.global_transform = mi.global_transform
	var cs := CollisionShape3D.new()
	var bs := BoxShape3D.new()
	bs.size = sz
	cs.shape = bs
	rb.add_child(cs)
	mi.reparent(rb, true)
	rb.contact_monitor = true
	rb.max_contacts_reported = 3
	rb.body_entered.connect(Blood.on_contact.bind(rb))
	rb.apply_central_impulse(Vector3(dir.x, 0.0, dir.z) * 1.2 + Vector3(randf() - 0.5, 0.6, randf() - 0.5))
	var end_y := sz.y * 0.5
	mi.add_child(_cap(Vector3(sz.x * 1.03, 0.04, sz.z * 1.03), Vector3(0, end_y, 0)))
	Fx.bleed(rb, 2.0, Vector3(0, end_y, 0), false)
	var jp := p["joint"] as Vector3
	(parts[0]["mi"] as Node3D).add_child(_cap(Vector3(0.16, 0.04, 0.16), jp - Vector3(0, 1.05, 0)))
	Fx.bleed(self, 6.0, jp, false)
	bleed_out += 6.0
	w.get_tree().create_timer(20.0).timeout.connect(rb.queue_free)
	if nm == "ll" or nm == "rl":
		fall(9999.0, false)

func die(dir: Vector3, gib: bool = false) -> void:
	if dead:
		return
	dead = true
	grabbed = false
	scream()
	var w := get_parent()
	var gx := global_transform
	var bodies := {}
	var detached := {}
	var k := 7.0 if (Cfg.gore == 2 or gib) else 3.0
	var cut := (Cfg.gore == 2) or (Cfg.gore == 1 and gib)
	for p in parts:
		var nm: String = p["name"]
		if severed.has(nm):
			detached[nm] = false
			continue
		detached[nm] = cut and nm != "torso" and (gib or randf() < 0.6)
		var mi := p["mi"] as MeshInstance3D
		var rb := RigidBody3D.new()
		rb.collision_layer = 4
		rb.collision_mask = 1 | 4 | 163
		rb.mass = 3.0 if nm == "torso" else 1.0
		w.add_child(rb)
		rb.global_transform = mi.global_transform
		var cs := CollisionShape3D.new()
		var bs := BoxShape3D.new()
		bs.size = p["size"] as Vector3
		cs.shape = bs
		rb.add_child(cs)
		mi.reparent(rb, true)
		bodies[nm] = rb
		rb.contact_monitor = true
		rb.max_contacts_reported = 3
		rb.body_entered.connect(Blood.on_contact.bind(rb))
		# без подлёта: только горизонтальный толчок по направлению выстрела
		rb.apply_central_impulse(Vector3(dir.x, 0.0, dir.z) * 1.6 + Vector3(randf() - 0.5, 0.0, randf() - 0.5) * k * 0.3)
		rb.apply_torque_impulse(Vector3(randf() - 0.5, randf() - 0.5, randf() - 0.5) * 0.8)
		w.get_tree().create_timer(20.0).timeout.connect(rb.queue_free)
	torso_rb = bodies["torso"] as RigidBody3D
	for p in parts:
		var nm: String = p["name"]
		if nm == "torso" or detached[nm] or severed.has(nm):
			continue
		var j := PinJoint3D.new()
		w.add_child(j)
		j.global_position = gx * (p["joint"] as Vector3)
		j.node_a = torso_rb.get_path()
		j.node_b = (bodies[nm] as Node).get_path()
		w.get_tree().create_timer(20.0).timeout.connect(j.queue_free)
	# оторванные части: красные срезы и струи крови
	for p in parts:
		var nm: String = p["name"]
		if nm == "torso" or not detached[nm]:
			continue
		var sz := p["size"] as Vector3
		var end_y := (-1.0 if nm == "head" else 1.0) * sz.y * 0.5
		(p["mi"] as Node3D).add_child(_cap(Vector3(sz.x * 1.03, 0.04, sz.z * 1.03), Vector3(0, end_y, 0)))
		Fx.bleed(bodies[nm] as Node3D, 2.0, Vector3(0, end_y, 0), nm == "head")
		var jp := p["joint"] as Vector3
		var tp := Vector3(0, 1.05, 0)
		(parts[0]["mi"] as Node3D).add_child(_cap(Vector3(0.16, 0.04, 0.16), jp - tp))
		Fx.bleed(torso_rb, 2.5, jp - tp, nm == "head")
	if Cfg.gore == 2 and (gib or randf() < 0.45):
		_guts(w, torso_rb, gx)
	if Cfg.gore > 0 and bleed_puddle == null:
		Blood.puddle(w, gx.origin, 1.1, 6.0)
	if Cfg.gore > 0:
		var n := 70 if Cfg.gore == 2 else 20
		if gib:
			n = 140
		Fx.burst(w, gx * Vector3(0, 1.1, 0), Color(0.67, 0.0, 0.06), n, 5.0, 0.04, 1.2)
	died.emit(self)
	queue_free()

# Хват: человека можно взять, дёргать и отпустить (он падает и встаёт)
func grab() -> void:
	if dead:
		return
	grabbed = true
	downed = false
	flee_t = 0.0

func release(vel: Vector3) -> void:
	if not grabbed:
		return
	grabbed = false
	if vel.length() > 1.0:
		fling = vel
		fling_t = 0.7
		pending_fall = true
	else:
		fall(2.5, false)

func _flail(delta: float) -> void:
	swing += delta * 14.0
	var k := clampf(shake * 0.08, 0.25, 1.4)
	var ph := {"la": 0.0, "ra": 1.7, "ll": 3.1, "rl": 4.6}
	for n in ph:
		var pv := piv[n] as Node3D
		var p: float = ph[n]
		pv.rotation = pv.rotation.lerp(Vector3(sin(swing + p) * 1.2 * k - 0.3, 0.0, cos(swing * 0.8 + p) * 0.7 * k), 0.4)
	rotation.x = lerpf(rotation.x, clampf(shake * 0.02, 0.0, 0.5), 0.2)
	position.y = maxf(position.y, 0.0)
	velocity = Vector3.ZERO
	if shake > 6.0:
		scream()

# Поза: шаг от бедра/плеча; если ранен, человек держится за место попадания
func _pose(s: float) -> void:
	var la := Vector3(-s * 0.8, 0.0, 0.05)
	var ra := Vector3(s * 0.8, 0.0, -0.05)
	var ll := Vector3(s, 0.0, 0.0)
	var rl := Vector3(-s, 0.0, 0.0)
	var lean := 0.0
	match hold_zone:
		"torso":
			la = Vector3(-1.15, 0.0, 0.6)
			ra = Vector3(-1.15, 0.0, -0.6)
			lean = 0.35
		"head":
			ra = Vector3(-2.7, 0.0, -0.2)
			lean = 0.1
		"legl":
			ll = Vector3(-0.2, 0.0, 0.0)
			la = Vector3(-0.9, 0.0, 0.25)
			ra = Vector3(-0.2, 0.0, -0.05)
			lean = 0.25
		"legr":
			rl = Vector3(-0.2, 0.0, 0.0)
			ra = Vector3(-0.9, 0.0, -0.25)
			la = Vector3(-0.2, 0.0, 0.05)
			lean = 0.25
	var tg := {"la": la, "ra": ra, "ll": ll, "rl": rl}
	for k in tg:
		var pv := piv[k] as Node3D
		pv.rotation = pv.rotation.lerp(tg[k] as Vector3, 0.3)
	var torso := parts[0]["mi"] as Node3D
	torso.rotation.x = lerpf(torso.rotation.x, lean, 0.2)

func _physics_process(delta: float) -> void:
	scream_cd = maxf(0.0, scream_cd - delta)
	if bleed_out > 0.0 and not dead and not spin:
		hp -= bleed_out * delta
		if hp <= 0.0:
			die(Vector3.ZERO)
			return
	if grabbed:
		_flail(delta)
		return
	if fling_t > 0.0:
		fling_t -= delta
		fling.y -= 20.0 * delta
		velocity = fling
		move_and_slide()
		if is_on_floor() and fling.y < 0.0:
			fling_t = 0.0
		if fling_t <= 0.0 and pending_fall:
			pending_fall = false
			fall(2.5, false)
		return
	if spin:
		rotate_y(2.0 * delta)
		return
	if not ai or dead:
		return
	if downed:
		down_t -= delta
		if down_t <= 0.0:
			stand()
		return
	if hp < 100.0 and Cfg.gore > 0:
		drip_t -= delta
		if drip_t <= 0.0:
			drip_t = 0.8 if Cfg.gore == 1 else 0.4
			Blood.puddle(get_parent(), global_position, randf_range(0.25, 0.45), 1.5)
	flee_t = maxf(0.0, flee_t - delta)
	wander_t -= delta
	var dir := Vector3.ZERO
	var spd := 1.3
	if flee_t > 0.0:
		dir = global_position - threat
		spd = 4.5
	else:
		if wander_t <= 0.0:
			wander_t = randf_range(2.0, 6.0)
			if randf() > 0.3:
				target = global_position + Vector3(randf_range(-10, 10), 0, randf_range(-10, 10))
			else:
				target = global_position
		dir = target - global_position
		if dir.length() < 0.5:
			dir = Vector3.ZERO
	dir.y = 0.0
	if dir.length() > 0.01:
		dir = dir.normalized()
		if hold_zone.begins_with("leg"):
			spd *= 0.5
		elif hold_zone == "torso":
			spd *= 0.75
		velocity = Vector3(dir.x * spd, -2.0, dir.z * spd)
		rotation.y = lerp_angle(rotation.y, atan2(dir.x, dir.z), 10.0 * delta)
		swing += delta * spd * 3.4
		var amp := clampf(spd * 0.2, 0.28, 0.85)
		_pose(sin(swing) * amp)
	else:
		velocity = Vector3(0, -2.0, 0)
		_pose(0.0)
	move_and_slide()
	wall_cd -= delta
	if hp < 100.0 and Cfg.gore > 0 and wall_cd <= 0.0:
		for i in get_slide_collision_count():
			var c := get_slide_collision(i)
			if c.get_collider() is StaticBody3D and absf(c.get_normal().y) < 0.5:
				Blood.splat(get_parent(), c.get_position(), c.get_normal())
				wall_cd = 0.6
				break
	global_position.x = clampf(global_position.x, -bound, bound)
	global_position.z = clampf(global_position.z, -bound, bound)
