extends Node
# Интро (видео, без пропуска) -> главное меню (2 человечка) -> карта -> игра

var ui: CanvasLayer
var world: Node3D = null
var cam: Camera3D = null
var foe: Human = null
var game: Game = null
var overlay: Control = null
var btn_tex: Texture2D
var click_snd: AudioStreamPlayer
var pending := Vector2(-1, -1)
var gen: int = 0
var sel_map: int = 0

func _ready() -> void:
	Cfg.load_cfg()
	btn_tex = load("res://assets/button.png") as Texture2D
	click_snd = AudioStreamPlayer.new()
	if ResourceLoader.exists("res://assets/audio/Glak.mp3"):
		click_snd.stream = load("res://assets/audio/Glak.mp3")
	add_child(click_snd)
	ui = CanvasLayer.new()
	add_child(ui)
	_start_intro()

func _clear() -> void:
	gen += 1
	for c in ui.get_children():
		c.queue_free()
	if world != null:
		world.queue_free()
		world = null
	cam = null
	foe = null
	overlay = null

# ---------- интро ----------
func _start_intro() -> void:
	var path := "res://assets/intro.ogv"
	if not ResourceLoader.exists(path):
		_show_menu()
		return
	var bg := ColorRect.new()
	bg.color = Color.BLACK
	ui.add_child(bg)
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var vp := VideoStreamPlayer.new()
	vp.stream = load(path)
	vp.expand = true
	vp.mouse_filter = Control.MOUSE_FILTER_STOP   # пропустить нельзя
	vp.finished.connect(_show_menu)
	ui.add_child(vp)
	vp.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	vp.play()

# ---------- меню ----------
func _box(size: Vector3, pos: Vector3, col: Color) -> void:
	Fx.box(world, size, pos, col)

func _human(pos: Vector3, col: Color) -> Human:
	var h := Human.new()
	h.setup(col)
	world.add_child(h)
	h.position = pos
	return h

func _show_menu() -> void:
	_clear()
	world = Node3D.new()
	add_child(world)
	var we := WorldEnvironment.new()
	var e := Environment.new()
	e.background_mode = Environment.BG_COLOR
	e.background_color = Color(0.08, 0.09, 0.1)
	e.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	e.ambient_light_color = Color(0.7, 0.7, 0.72)
	e.ambient_light_energy = 0.8
	we.environment = e
	world.add_child(we)
	var l := OmniLight3D.new()
	l.position = Vector3(0, 3.5, 2.5)
	l.omni_range = 14.0
	l.light_energy = 2.0
	world.add_child(l)
	_box(Vector3(14, 1, 14), Vector3(0, -0.5, 0), Color(0.33, 0.34, 0.36))
	_box(Vector3(14, 6, 1), Vector3(0, 3, -3.5), Color(0.23, 0.24, 0.25))
	_box(Vector3(1, 6, 14), Vector3(-6, 3, 0), Color(0.23, 0.24, 0.25))
	_box(Vector3(1, 6, 14), Vector3(6, 3, 0), Color(0.23, 0.24, 0.25))
	cam = Camera3D.new()
	world.add_child(cam)
	cam.position = Vector3(0, 1.5, 5.2)
	cam.rotation.x = -0.08
	cam.make_current()
	var hero := _human(Vector3(-1.3, 0, 0), Color(0.23, 0.48, 0.84))   # главный герой, стоит
	hero.rotation.y = 0.3
	_spawn_foe()
	_menu_ui()

func _spawn_foe() -> void:
	foe = _human(Vector3(1.3, 0, 0), Color(0.77, 0.09, 0.11))          # крутится, в него можно стрелять
	foe.spin = true
	foe.died.connect(_foe_died)

func _foe_died(_h) -> void:
	var g := gen
	get_tree().create_timer(3.0).timeout.connect(func():
		if g == gen and game == null and world != null:
			_spawn_foe())

func _btn(text: String, cb: Callable, w: float = 260.0, h: float = 86.0) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(w, h)
	var sb := StyleBoxTexture.new()
	sb.texture = btn_tex
	var sp := StyleBoxTexture.new()
	sp.texture = btn_tex
	sp.modulate_color = Color(0.7, 0.7, 0.7)
	for n in ["normal", "hover", "focus", "disabled"]:
		b.add_theme_stylebox_override(n, sb)
	for n in ["pressed", "hover_pressed"]:
		b.add_theme_stylebox_override(n, sp)
	for c in ["font_color", "font_hover_color", "font_pressed_color", "font_focus_color", "font_hover_pressed_color"]:
		b.add_theme_color_override(c, Color.BLACK)
	b.add_theme_font_size_override("font_size", 30)
	if cb.is_valid():
		b.pressed.connect(cb)
	return b

func _menu_ui() -> void:
	var root := Control.new()
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ui.add_child(root)
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var top := CenterContainer.new()
	top.mouse_filter = Control.MOUSE_FILTER_IGNORE
	top.custom_minimum_size = Vector2(0, 240)
	root.add_child(top)
	top.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE)
	var pc := PanelContainer.new()
	pc.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.91, 0.91, 0.89)
	sb.set_content_margin_all(10)
	pc.add_theme_stylebox_override("panel", sb)
	top.add_child(pc)
	var tr := TextureRect.new()
	tr.texture = load("res://assets/logo.png") as Texture2D
	tr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	tr.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	tr.custom_minimum_size = Vector2(360, 185)
	tr.mouse_filter = Control.MOUSE_FILTER_IGNORE
	pc.add_child(tr)
	var bot := HBoxContainer.new()
	bot.alignment = BoxContainer.ALIGNMENT_CENTER
	bot.mouse_filter = Control.MOUSE_FILTER_IGNORE
	bot.add_theme_constant_override("separation", 24)
	bot.custom_minimum_size = Vector2(0, 130)
	root.add_child(bot)
	bot.grow_vertical = Control.GROW_DIRECTION_BEGIN
	bot.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_WIDE, Control.PRESET_MODE_MINSIZE)
	bot.add_child(_btn("Играть", _map_panel))
	bot.add_child(_btn("Настройки", _settings_panel))

func _open_panel() -> VBoxContainer:
	if overlay != null:
		overlay.queue_free()
	overlay = ColorRect.new()
	(overlay as ColorRect).color = Color(0.08, 0.09, 0.1, 0.94)
	ui.add_child(overlay)
	overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var cc := CenterContainer.new()
	overlay.add_child(cc)
	cc.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 14)
	vb.alignment = BoxContainer.ALIGNMENT_CENTER
	cc.add_child(vb)
	return vb

func _title(vb: Control, t: String) -> void:
	var l := Label.new()
	l.text = t
	l.add_theme_font_size_override("font_size", 38)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vb.add_child(l)

func _close_panel() -> void:
	if overlay != null:
		overlay.queue_free()
		overlay = null

func _map_panel() -> void:
	var vb := _open_panel()
	_title(vb, "Выберите карту")
	var mb: Array = []
	for i in Maps.NAMES.size():
		var b := _btn("", Callable(), 440.0, 58.0)
		mb.append(b)
		vb.add_child(b)
	var upd := func():
		for i in mb.size():
			(mb[i] as Button).text = ("> " if i == sel_map else "") + Maps.NAMES[i]
	for i in mb.size():
		(mb[i] as Button).pressed.connect(func():
			sel_map = i
			upd.call())
	upd.call()
	vb.add_child(_btn("Играть", _start_game, 440.0, 64.0))
	vb.add_child(_btn("Назад", _close_panel, 440.0, 58.0))

func _settings_panel() -> void:
	var vb := _open_panel()
	_title(vb, "Настройки")
	var bc := _btn("", Callable(), 420.0)
	var gr := _btn("", Callable(), 420.0)
	var upd := func():
		bc.text = "Бодикам: " + ("ВКЛ" if Cfg.bodycam else "ВЫКЛ")
		gr.text = "Расчленёнка: " + Cfg.GORE_NAMES[Cfg.gore]
	bc.pressed.connect(func():
		Cfg.bodycam = not Cfg.bodycam
		Cfg.save_cfg()
		upd.call())
	gr.pressed.connect(func():
		Cfg.gore = (Cfg.gore + 1) % 3
		Cfg.save_cfg()
		upd.call())
	upd.call()
	vb.add_child(bc)
	vb.add_child(gr)
	vb.add_child(_btn("Назад", _close_panel, 420.0))

# ---------- игра ----------
func _start_game() -> void:
	_clear()
	game = Game.new()
	game.map_id = sel_map
	game.exit_menu.connect(_back_from_game)
	add_child(game)

func _back_from_game() -> void:
	if game != null:
		game.queue_free()
		game = null
	_show_menu()

# ---------- выстрел по крутящемуся человеку в меню ----------
func _unhandled_input(event: InputEvent) -> void:
	if game != null or world == null:
		return
	if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		pending = event.position

func _physics_process(_delta: float) -> void:
	if pending.x < 0.0:
		return
	if cam != null and world != null and game == null:
		var o := cam.project_ray_origin(pending)
		var d := cam.project_ray_normal(pending)
		var q := PhysicsRayQueryParameters3D.create(o, o + d * 30.0, 2)
		var r := world.get_world_3d().direct_space_state.intersect_ray(q)
		click_snd.play()
		if not r.is_empty():
			var h = r.collider
			if h is Human and h.spin:
				h.die(d * 2.5)
	pending = Vector2(-1, -1)
