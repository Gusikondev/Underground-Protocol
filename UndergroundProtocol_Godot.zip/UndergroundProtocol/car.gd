class_name Car
extends RigidBody3D
# Машина (аркадная физика на RigidBody3D): давит людей, сносит кирпичи и бочки.
# Вид из кабины (cam), мокрая земля снижает сцепление.

var kind: int = 0
var throttle: float = 0.0
var steer: float = 0.0
var braking: bool = false
var occupied: bool = false
var wet: bool = false
var speed: float = 0.0
var cam: Camera3D
const MAXV := [26.0, 21.0, 31.0]
const NAMES := ["Седан", "Пикап", "Дрифт-кар"]
var slip: float = 0.0
var smokes: Array = []

func _b(size: Vector3, pos: Vector3, col: Color, rot: Vector3 = Vector3.ZERO) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	var m := StandardMaterial3D.new()
	m.albedo_color = col
	mi.material_override = m
	mi.position = pos
	mi.rotation = rot
	add_child(mi)
	return mi

func build(k: int) -> void:
	kind = k
	add_to_group("cars")
	collision_layer = 32
	collision_mask = 113
	mass = 900.0
	axis_lock_angular_x = true
	axis_lock_angular_z = true
	angular_damp = 2.0
	var pm := PhysicsMaterial.new()
	pm.friction = 0.0
	physics_material_override = pm
	var cs := CollisionShape3D.new()
	var sh := BoxShape3D.new()
	sh.size = Vector3(1.9, 1.1, 4.8 if k == 1 else 4.3)
	cs.shape = sh
	cs.position = Vector3(0, 0.8, 0)
	add_child(cs)
	var paint := Color(0.7, 0.1, 0.1) if k == 0 else Color(0.28, 0.36, 0.2)
	if k == 2:
		paint = Color(0.93, 0.93, 0.96)
	var glass := Color(0.08, 0.1, 0.13)
	var dark := Color(0.06, 0.06, 0.07)
	if k == 2:
		_b(Vector3(1.95, 0.5, 4.3), Vector3(0, 0.62, 0), paint)
		_b(Vector3(1.5, 0.42, 1.9), Vector3(0, 1.1, 0.35), paint)
		_b(Vector3(1.52, 0.3, 1.7), Vector3(0, 1.13, 0.35), glass)
		_b(Vector3(0.5, 0.02, 2.2), Vector3(0, 0.9, -1.0), Color(0.1, 0.35, 0.9))
		_b(Vector3(0.08, 0.35, 0.08), Vector3(-0.7, 1.05, 1.95), dark)
		_b(Vector3(0.08, 0.35, 0.08), Vector3(0.7, 1.05, 1.95), dark)
		_b(Vector3(2.1, 0.06, 0.55), Vector3(0, 1.27, 1.95), dark)
		var glow := _b(Vector3(1.7, 0.03, 3.6), Vector3(0, 0.22, 0), Color(0.1, 0.9, 1.0))
		(glow.material_override as StandardMaterial3D).emission_enabled = true
		(glow.material_override as StandardMaterial3D).emission = Color(0.1, 0.9, 1.0)
		for sx in [-0.95, 0.95]:
			var p := CPUParticles3D.new()
			var sm := SphereMesh.new()
			sm.radius = 0.25
			sm.height = 0.5
			var smat := StandardMaterial3D.new()
			smat.albedo_color = Color(0.85, 0.85, 0.85, 0.5)
			smat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
			smat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
			sm.material = smat
			p.mesh = sm
			p.amount = 24
			p.lifetime = 1.0
			p.direction = Vector3.UP
			p.spread = 30.0
			p.initial_velocity_min = 0.5
			p.initial_velocity_max = 1.5
			p.gravity = Vector3(0, 0.5, 0)
			p.scale_amount_min = 0.6
			p.scale_amount_max = 1.4
			p.emitting = false
			p.position = Vector3(sx, 0.2, 1.4)
			add_child(p)
			smokes.append(p)
	elif k == 0:
		_b(Vector3(1.9, 0.65, 4.3), Vector3(0, 0.72, 0), paint)
		_b(Vector3(1.6, 0.6, 2.2), Vector3(0, 1.3, 0.15), paint)
		_b(Vector3(1.62, 0.4, 2.0), Vector3(0, 1.33, 0.15), glass)
	else:
		_b(Vector3(2.0, 0.7, 4.8), Vector3(0, 0.8, 0), paint)
		_b(Vector3(1.9, 0.75, 1.7), Vector3(0, 1.45, -0.8), paint)
		_b(Vector3(1.92, 0.45, 1.5), Vector3(0, 1.5, -0.8), glass)
		_b(Vector3(0.1, 0.35, 2.0), Vector3(-0.95, 1.3, 1.2), paint)
		_b(Vector3(0.1, 0.35, 2.0), Vector3(0.95, 1.3, 1.2), paint)
		_b(Vector3(1.9, 0.35, 0.1), Vector3(0, 1.3, 2.2), paint)
	var zf := -2.15 if k == 0 else -2.4
	_b(Vector3(0.4, 0.15, 0.08), Vector3(-0.6, 0.85, zf), Color(1, 0.95, 0.7))
	_b(Vector3(0.4, 0.15, 0.08), Vector3(0.6, 0.85, zf), Color(1, 0.95, 0.7))
	_b(Vector3(0.4, 0.15, 0.08), Vector3(-0.6, 0.85, -zf), Color(0.8, 0.05, 0.05))
	_b(Vector3(0.4, 0.15, 0.08), Vector3(0.6, 0.85, -zf), Color(0.8, 0.05, 0.05))
	_b(Vector3(1.9, 0.15, 0.12), Vector3(0, 0.45, zf), dark)
	for sx in [-0.95, 0.95]:
		for sz in [-1.35, 1.35]:
			var mi := MeshInstance3D.new()
			var cy := CylinderMesh.new()
			cy.top_radius = 0.38
			cy.bottom_radius = 0.38
			cy.height = 0.3
			mi.mesh = cy
			var m := StandardMaterial3D.new()
			m.albedo_color = dark
			mi.material_override = m
			mi.position = Vector3(sx, 0.38, sz)
			mi.rotation = Vector3(0, 0, PI / 2.0)
			add_child(mi)
	# камера водителя: сидение слева, можно осматриваться (game.gd крутит cam.rotation)
	cam = Camera3D.new()
	cam.fov = 75.0
	cam.near = 0.05
	cam.position = Vector3(-0.4, 1.55, -0.1 if k == 0 else -0.8)
	add_child(cam)

# throttle: вперёд +1, steer: вправо +1, brake: стоп-кран
func drive(thr: float, st: float, brake: bool, _delta: float) -> void:
	throttle = thr
	steer = st
	braking = brake

func shot(pt: Vector3, _dir: Vector3) -> void:
	Fx.burst(get_parent(), pt, Color(1.0, 0.8, 0.3), 5, 3.0, 0.02, 0.3)

func blast_hit(pos: Vector3, _r: float) -> void:
	var away := (global_position - pos)
	away.y = 0.0
	apply_central_impulse(away.normalized() * mass * 6.0 + Vector3.UP * mass * 3.0)

func _integrate_forces(state: PhysicsDirectBodyState3D) -> void:
	var t := state.transform
	var fwd := -t.basis.z
	var right := t.basis.x
	var v := state.linear_velocity
	var vf := v.dot(fwd)
	var vr := v.dot(right)
	var maxv: float = MAXV[kind] * (0.75 if wet else 1.0)
	var vr0 := vr
	var target := 0.0
	var rate := 6.0
	if occupied:
		target = throttle * (maxv if throttle > 0.0 else maxv * 0.4)
		rate = (12.0 if absf(target) > absf(vf) else 22.0) * (0.6 if wet else 1.0)
		if kind == 2:
			rate *= 1.4
		if braking and kind != 2:
			target = 0.0
			rate = 40.0
	vf = move_toward(vf, target, rate * state.step)
	var grip := 8.0 if wet else 30.0
	if kind == 2:
		# дрифт: низкое боковое сцепление, ручник почти отключает его
		grip = 1.2 if braking else 7.0
		grip *= (1.0 - 0.55 * absf(steer) * clampf(absf(vf) / 18.0, 0.0, 1.0))
	vr = move_toward(vr, 0.0, grip * state.step)
	slip = vr0
	state.linear_velocity = fwd * vf + right * vr + Vector3(0, v.y, 0)
	var yaw_rate := 0.0
	if occupied:
		var mag := clampf(vf / 6.0, -1.0, 1.0)
		if kind == 2:
			mag = clampf(maxf(absf(vf), absf(vr0) * 0.7) / 6.0, 0.0, 1.0) * (1.0 if vf >= -0.5 else -1.0)
		yaw_rate = -steer * mag * (2.2 if kind == 2 else 1.5) * (1.3 if (kind == 2 and braking) else 1.0)
	var av := state.angular_velocity
	av.y = yaw_rate
	state.angular_velocity = av
	speed = vf

func _physics_process(_delta: float) -> void:
	for p in smokes:
		(p as CPUParticles3D).emitting = occupied and absf(slip) > 3.0 and absf(speed) > 6.0
	if absf(speed) < 5.0:
		return
	var inv := global_transform.affine_inverse()
	for h in get_tree().get_nodes_in_group("humans"):
		var rel: Vector3 = inv * (h as Node3D).global_position
		if absf(rel.x) < 1.3 and absf(rel.z) < 2.6 and (h as Human).dead == false:
			(h as Human).die(linear_velocity * 0.3 + Vector3.UP * 2.0)
