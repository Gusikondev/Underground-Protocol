class_name Cfg
extends RefCounted
# Настройки игры (сохраняются в user://cfg.cfg)

static var bodycam: bool = false
static var gore: int = 1  # 0 мирный, 1 средний, 2 садистский
static var weather: int = 0  # 0 авто, 1 ясно, 2 дождь

const PATH := "user://cfg.cfg"
const GORE_NAMES := ["Мирный", "Средний", "Садистский"]
const WEATHER_NAMES := ["Авто", "Ясно", "Дождь"]

static func load_cfg() -> void:
	var c := ConfigFile.new()
	if c.load(PATH) == OK:
		bodycam = bool(c.get_value("s", "bodycam", false))
		gore = int(c.get_value("s", "gore", 1))
		weather = int(c.get_value("s", "weather", 0))

static func save_cfg() -> void:
	var c := ConfigFile.new()
	c.set_value("s", "bodycam", bodycam)
	c.set_value("s", "gore", gore)
	c.set_value("s", "weather", weather)
	c.save(PATH)
