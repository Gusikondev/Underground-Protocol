class_name Blood
extends RefCounted
# Лужи и брызги крови (плоские картинки на полу и стенах)

const SPLATS := ["res://assets/blood/splat0.png", "res://assets/blood/splat1.png", "res://assets/blood/splat2.png"]
const PUDDLE := "res://assets/blood/puddle.png"
const MAX := 160

static var cache: Dictionary = {}
static var decals: Array = []

static func _tex(path: String) -> Texture2D:
	if not cache.has(path):
		cache[path] = load(path) if ResourceLoader.exists(path) else null
	return cache[path] as Texture2D

static func _quad(parent: Node, tex: Texture2D, size: float, pos: Vector3, n: Vector3) -> MeshInstance3D:
	if tex == null or Cfg.gore == 0 or parent == null or not is_instance_valid(parent):
		return null
	var mi := MeshInstance3D.new()
	var q := QuadMesh.new()
	q.size = Vector2(size, size)
	var m := StandardMaterial3D.new()
	m.albedo_texture = tex
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.cull_mode = BaseMaterial3D.CULL_DISABLED
	mi.mesh = q
	mi.material_override = m
	parent.add_child(mi)
	var up := Vector3.UP if absf(n.y) < 0.99 else Vector3.RIGHT
	var off := 0.012 + 0.0015 * float(decals.size() % 30)
	mi.global_transform = Transform3D(Basis.looking_at(-n, up), pos + n * off)
	mi.rotate_object_local(Vector3(0, 0, 1), randf() * TAU)
	decals.append(mi)
	while decals.size() > MAX:
		var o = decals.pop_front()
		if is_instance_valid(o):
			(o as Node).queue_free()
	return mi

static func _k() -> float:
	return 1.0 if Cfg.gore <= 1 else 1.7

# Лужа на полу, растёт за grow секунд
static func puddle(parent: Node, pos: Vector3, size: float, grow: float) -> MeshInstance3D:
	var mi := _quad(parent, _tex(PUDDLE), size * _k(), Vector3(pos.x, 0.0, pos.z), Vector3.UP)
	if mi != null:
		mi.scale = Vector3.ONE * 0.1
		mi.create_tween().tween_property(mi, "scale", Vector3.ONE, grow)
	return mi

# Случайная картинка брызг на поверхности (pos, нормаль n)
static func splat(parent: Node, pos: Vector3, n: Vector3) -> void:
	var ok: Array = []
	for p in SPLATS:
		if _tex(p) != null:
			ok.append(p)
	if ok.is_empty():
		return
	_quad(parent, _tex(ok[randi() % ok.size()]), randf_range(0.5, 1.0) * _k(), pos, n)

# Часть рэгдолла коснулась объекта -> брызги на нём
static func on_contact(body: Node, rb: RigidBody3D) -> void:
	if Cfg.gore == 0 or not (body is StaticBody3D) or not is_instance_valid(rb) or not rb.is_inside_tree():
		return
	var cnt: int = int(rb.get_meta("sp", 0))
	if cnt >= 2:
		return
	rb.set_meta("sp", cnt + 1)
	rb.get_tree().process_frame.connect(func(): _do_contact(rb), CONNECT_ONE_SHOT)

static func _do_contact(rb: RigidBody3D) -> void:
	if not is_instance_valid(rb) or not rb.is_inside_tree():
		return
	var v := rb.linear_velocity
	var d := v.normalized() if v.length() > 0.5 else Vector3.DOWN
	var from := rb.global_position - d * 0.15
	var q := PhysicsRayQueryParameters3D.create(from, from + d * 1.0, 1)
	var r := rb.get_world_3d().direct_space_state.intersect_ray(q)
	if not r.is_empty():
		splat(rb.get_parent(), r.position, r.normal)
