class_name Game
extends Node3D
# Игра: карты, оружие+обвесы, грав-пушка, машины, дрон, погода, бодикам, lean, ноги, пиво

signal exit_menu

const HIP_R := Vector3(0.2, -0.25, -0.52)   # справа (как в мобильных шутерах)
const HIP_C := Vector3(0.03, -0.26, -0.52)  # по центру (бодикам)
const AIM := Vector3(0.0, -0.17, -0.38)

const WEAPONS := [
	{"name": "Пистолет", "kind": "pistol", "sever": 0.7, "dmg": 40.0, "cd": 0.35, "auto": false, "pel": 1, "spread": 0.01, "snd": "res://assets/audio/Glak.mp3"},
	{"name": "Автомат", "kind": "ak", "sever": 1.0, "dmg": 25.0, "cd": 0.09, "auto": true, "pel": 1, "spread": 0.025, "snd": "res://assets/audio/Kok.mp3"},
	{"name": "Дробовик", "kind": "shotgun", "sever": 2.0, "dmg": 28.0, "cd": 0.9, "auto": false, "pel": 8, "spread": 0.09, "snd": "res://assets/audio/shotgun.mp3"},
	{"name": "Грав-пушка", "kind": "grav", "dmg": 0.0, "cd": 0.3, "auto": false, "pel": 0, "spread": 0.0, "snd": ""},
	{"name": "ПП", "kind": "smg", "sever": 0.6, "dmg": 14.0, "cd": 0.055, "auto": true, "pel": 1, "spread": 0.04, "snd": "res://assets/audio/Kok.mp3", "pitch": 1.5},
	{"name": "Снайперка", "kind": "sniper", "sever": 3.0, "dmg": 110.0, "cd": 1.2, "auto": false, "pel": 1, "spread": 0.0, "snd": "res://assets/audio/shotgun.mp3", "pitch": 0.75, "zoom": 14.0},
	{"name": "Револьвер", "kind": "revolver", "sever": 1.6, "dmg": 65.0, "cd": 0.55, "auto": false, "pel": 1, "spread": 0.008, "snd": "res://assets/audio/Glak.mp3", "pitch": 0.7},
	{"name": "РПГ", "kind": "rpg", "sever": 0.0, "dmg": 40.0, "cd": 2.2, "auto": false, "pel": 1, "spread": 0.0, "snd": "res://assets/audio/shotgun.mp3", "pitch": 0.5, "boom": true},
	{"name": "Кулаки", "kind": "fists", "sever": 0.0, "dmg": 12.0, "cd": 0.45, "auto": true, "pel": 0, "spread": 0.0, "snd": "res://assets/audio/Glak.mp3", "pitch": 0.35, "melee": true},
	{"name": "Бензопила", "kind": "chainsaw", "sever": 4.0, "dmg": 22.0, "cd": 0.1, "auto": true, "pel": 0, "spread": 0.0, "snd": "", "melee": true, "saw": true},
]
const FISTS := 8
const SAW := 9
const FOOT_BTNS := ["grab", "fire", "aim", "kick", "weapon", "attach", "leanl", "leanr"]

var map_id: int = 0
var wi: int = 0
var player: CharacterBody3D
var head: Node3D
var cam: Camera3D
var weapon_root: Node3D
var flash: OmniLight3D
var views: Array = []
var sfx: Array = []
var att: Array = []
var boom_snd: AudioStreamPlayer
var env: Environment
var weather: Weather
var mud: Array = []
var road_mat: StandardMaterial3D = null
var spawn_pos: Vector3 = Vector3(0, 0, 10)
var human_pos: Array = []
var legs: Node3D
var beam: MeshInstance3D
var beam_mat: StandardMaterial3D
var xh_rects: Array = []
var kick_leg: Node3D

var hud: CanvasLayer
var S: Vector2
var btns: Dictionary = {}
var joy_ring: Panel
var joy_knob: Panel
var joy_center: Vector2
var st_label: Label
var acro: Label
var toast: Label
var spawn_panel: PanelContainer
var spawn_items: VBoxContainer
var att_panel: PanelContainer
var att_btns: Array = []
var bc_label: Label
var lens_mat: ShaderMaterial = null

var joy := Vector2.ZERO
var look_acc := Vector2.ZERO
var lag := Vector2.ZERO
var yaw: float = 0.0
var pitch: float = 0.0
var car_yaw: float = 0.0
var aim_on: bool = false
var aim_t: float = 0.0
var fire_held: bool = false
var fire_edge: bool = false
var fire_cd: float = 0.0
var kick_req: bool = false
var recoil: float = 0.0
var up_held: bool = false
var down_held: bool = false
var lean_l: bool = false
var lean_r: bool = false
var lean_cur: float = 0.0
var brake_held: bool = false
var bob_t: float = 0.0
var t_acc: float = 0.0
var drunk: float = 0.0
var drone: Drone = null
var ctrl: bool = false
var car: Car = null
var near_beer: Node3D = null
var near_car: Car = null
var held: RigidBody3D = null
var held_h: Human = null
var punch_t: float = -1.0
var punch_side: int = 0
var punch_done: bool = false
var saw_snd: AudioStreamPlayer
var saw_on: bool = false
var near_victim: Human = null
var fin_active: bool = false
var fin_t: float = 0.0
var fin_hit: bool = false
var fin_gib: bool = false
var fin_victim: Human = null
var fin_avatar: Human = null
var fin_saw: Node3D = null
var fin_cam: Camera3D = null
var fin_dir: Vector3 = Vector3.FORWARD
var fin_v: Vector3 = Vector3.ZERO
var fin_last: Vector3 = Vector3.ZERO
var flash_t: float = 0.0
var held_dist: float = 3.0
var kills: int = 0
var touches: Dictionary = {}

func _ready() -> void:
	randomize()
	S = get_viewport().get_visible_rect().size
	_build_world()
	_build_player()
	_build_hud()
	weather = Weather.new()
	add_child(weather)
	weather.setup(env, env.background_color, env.fog_density)
	for p in human_pos:
		_spawn_human(p as Vector3)
	if map_id == 3:
		_spawn_car(2)
	_set_weapon(0)
	_apply_mode()

# ---------------- мир ----------------
func _build_world() -> void:
	var info := Maps.build(self, map_id)
	Human.bound = float(info["bound"]) - 2.0
	mud = info["mud"]
	road_mat = info["road_mat"]
	spawn_pos = info["spawn"]
	human_pos = info["humans"]
	var we := WorldEnvironment.new()
	env = Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = info["sky"]
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.75, 0.75, 0.78)
	env.ambient_light_energy = 0.9
	env.fog_enabled = true
	env.fog_light_color = info["sky"]
	env.fog_density = float(info["fog"])
	we.environment = env
	add_child(we)
	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-50, 30, 0)
	add_child(sun)

func _spawn_human(pos: Vector3) -> void:
	var h := Human.new()
	h.setup(Color.from_hsv(randf(), 0.5, 0.55))
	h.ai = true
	add_child(h)
	h.global_position = pos
	h.died.connect(_on_died)

func _on_died(_h) -> void:
	kills += 1
	_update_stats()

func _scare(r: float, t: float) -> void:
	for h in get_tree().get_nodes_in_group("humans"):
		if h.global_position.distance_to(player.global_position) < r:
			h.flee_t = t
			h.threat = player.global_position

func in_mud(p: Vector3) -> bool:
	for r in mud:
		if (r as Rect2).has_point(Vector2(p.x, p.z)):
			return true
	return false

# общий взрыв: люди, пиво, стены, машины, бочки
func _blast(pos: Vector3, r: float) -> void:
	Fx.burst(self, pos, Color(1.0, 0.55, 0.0), 40, 8.0, 0.12, 0.7)
	Fx.explosion(self, pos, r * 1.4)
	boom_snd.play()
	for h in get_tree().get_nodes_in_group("humans"):
		var dv: Vector3 = h.global_position - pos
		if dv.length() < r:
			(h as Human).die((dv.normalized() + Vector3.UP).normalized() * 1.8, true)
	for b in get_tree().get_nodes_in_group("beer"):
		if b.global_position.distance_to(pos) < r:
			(b as Beer).smash()
	for w in get_tree().get_nodes_in_group("brickwalls"):
		(w as BrickWall).break_near(pos, r + 2.0, Vector3.ZERO)
	for c in get_tree().get_nodes_in_group("cars"):
		if c.global_position.distance_to(pos) < r * 1.5:
			(c as Car).blast_hit(pos, 6.0)
	for b in get_tree().get_nodes_in_group("barrels"):
		var dd: float = b.global_position.distance_to(pos)
		if dd < r and dd > 0.3:
			(b as Barrel).explode(0.15)

# ---------------- игрок ----------------
func _bx(p: Node3D, size: Vector3, pos: Vector3, c: Color) -> void:
	Guns.box(p, size, pos, c)

func _build_player() -> void:
	player = CharacterBody3D.new()
	player.collision_layer = 8
	player.collision_mask = 1
	var cs := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = 0.35
	cap.height = 1.7
	cs.shape = cap
	cs.position = Vector3(0, 0.85, 0)
	player.add_child(cs)
	add_child(player)
	player.position = spawn_pos
	head = Node3D.new()
	head.position = Vector3(0, 1.6, 0)
	player.add_child(head)
	cam = Camera3D.new()
	cam.fov = 70.0
	cam.near = 0.03
	head.add_child(cam)
	cam.make_current()
	weapon_root = Node3D.new()
	weapon_root.position = HIP_C if Cfg.bodycam else HIP_R
	cam.add_child(weapon_root)
	flash = OmniLight3D.new()
	flash.light_color = Color(1, 0.8, 0.5)
	flash.light_energy = 0.0
	flash.omni_range = 6.0
	cam.add_child(flash)
	for w in WEAPONS:
		var d := Guns.build(w["kind"])
		(d["root"] as Node3D).visible = false
		weapon_root.add_child(d["root"])
		if w["kind"] != "grav" and w["kind"] != "fists" and w["kind"] != "chainsaw":
			var fs := Sprite3D.new()
			fs.texture = Fx.tex("res://assets/fx/vsp.png")
			fs.billboard = BaseMaterial3D.BILLBOARD_ENABLED
			fs.shaded = false
			fs.double_sided = true
			fs.pixel_size = (0.6 if w["kind"] in ["shotgun", "sniper", "rpg"] else 0.4) / 256.0
			fs.position = d["muzzle"] as Vector3
			fs.visible = false
			(d["root"] as Node3D).add_child(fs)
			d["flash"] = fs
		views.append(d)
		att.append({"scope": false, "supp": false, "laser": false})
		var sp := AudioStreamPlayer.new()
		sp.max_polyphony = 4
		sp.pitch_scale = float(w.get("pitch", 1.0))
		if w["snd"] != "" and ResourceLoader.exists(w["snd"]):
			sp.stream = load(w["snd"])
		add_child(sp)
		sfx.append(sp)
	boom_snd = AudioStreamPlayer.new()
	boom_snd.pitch_scale = 0.5
	if ResourceLoader.exists("res://assets/audio/shotgun.mp3"):
		boom_snd.stream = load("res://assets/audio/shotgun.mp3")
	add_child(boom_snd)
	saw_snd = AudioStreamPlayer.new()
	if ResourceLoader.exists("res://assets/audio/saw.wav"):
		saw_snd.stream = load("res://assets/audio/saw.wav")
	add_child(saw_snd)
	beam = MeshInstance3D.new()
	var bcm := CylinderMesh.new()
	bcm.top_radius = 0.012
	bcm.bottom_radius = 0.012
	bcm.height = 1.0
	beam.mesh = bcm
	beam_mat = StandardMaterial3D.new()
	beam_mat.albedo_color = Color(0.4, 0.9, 1.0, 0.9)
	beam_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	beam_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	beam.material_override = beam_mat
	beam.visible = false
	add_child(beam)
	# ноги от первого лица (видны, если посмотреть вниз)
	legs = Node3D.new()
	player.add_child(legs)
	for x in [-0.13, 0.13]:
		_bx(legs, Vector3(0.14, 0.85, 0.17), Vector3(x, 0.45, 0.12), Color(0.16, 0.2, 0.31))
		_bx(legs, Vector3(0.15, 0.1, 0.3), Vector3(x, 0.05, 0.04), Color(0.08, 0.08, 0.09))
	# нога для пинка
	kick_leg = Node3D.new()
	kick_leg.position = Vector3(0.2, -0.38, -0.05)
	kick_leg.visible = false
	cam.add_child(kick_leg)
	_bx(kick_leg, Vector3(0.16, 0.85, 0.17), Vector3(0, -0.43, 0), Color(0.16, 0.2, 0.31))
	_bx(kick_leg, Vector3(0.16, 0.1, 0.32), Vector3(0, -0.87, -0.08), Color(0.08, 0.08, 0.09))

func _set_weapon(i: int) -> void:
	_drop_held()
	wi = i
	for k in views.size():
		(views[k]["root"] as Node3D).visible = (k == i) and car == null and not ctrl
	_set_btn_text("weapon", WEAPONS[i]["name"])
	_refresh_att()

func _refresh_att() -> void:
	for k in views.size():
		var v: Dictionary = views[k]
		if v.has("scope"):
			(v["scope"] as Node3D).visible = att[k]["scope"]
			(v["supp"] as Node3D).visible = att[k]["supp"]
			(v["laser"] as Node3D).visible = att[k]["laser"]
	if att_btns.size() == 3:
		var keys := ["scope", "supp", "laser"]
		var names := ["Прицел", "Глушитель", "Лазер"]
		for i in 3:
			var b := att_btns[i] as Button
			b.disabled = (wi == 3 or wi == FISTS or wi == SAW)
			b.text = "%s: %s" % [names[i], "ВКЛ" if att[wi][keys[i]] else "ВЫКЛ"]

func _toggle_att(key: String) -> void:
	if wi == 3 or wi == FISTS or wi == SAW:
		return
	att[wi][key] = not att[wi][key]
	_refresh_att()

func _show_toast(t: String) -> void:
	toast.text = t
	toast.modulate.a = 1.0
	create_tween().tween_property(toast, "modulate:a", 0.0, 1.8)

# ---------------- стрельба ----------------
func shoot() -> void:
	if fire_cd > 0.0:
		return
	var w: Dictionary = WEAPONS[wi]
	fire_cd = w["cd"]
	if wi == 3:
		_gravity_fire()
		return
	if w.get("saw", false):
		_saw_tick()
		return
	if w.get("melee", false):
		if punch_t < 0.0:
			punch_t = 0.0
			punch_done = false
		return
	recoil = 1.0
	var a: Dictionary = att[wi]
	var sp_node := sfx[wi] as AudioStreamPlayer
	sp_node.volume_db = -14.0 if a["supp"] else 0.0
	sp_node.play()
	_scare(15.0 if a["supp"] else 40.0, 6.0)
	if views[wi].has("flash") and not a["supp"]:
		(views[wi]["flash"] as Sprite3D).visible = true
		(views[wi]["flash"] as Sprite3D).scale = Vector3.ONE * randf_range(0.7, 1.2)
		flash_t = 0.05
	flash.position = weapon_root.position + (views[wi]["muzzle"] as Vector3) + Vector3(0, 0, -0.1)
	var space := get_world_3d().direct_space_state
	var xf := cam.global_transform
	var sp: float = float(w["spread"]) * (1.0 - 0.6 * aim_t) * (0.8 if a["laser"] else 1.0)
	for i in int(w["pel"]):
		var d := (-xf.basis.z + xf.basis.x * randf_range(-sp, sp) + xf.basis.y * randf_range(-sp, sp)).normalized()
		var q := PhysicsRayQueryParameters3D.create(xf.origin, xf.origin + d * 150.0, 1 | 2 | 4 | 16)
		var r := space.intersect_ray(q)
		if r.is_empty():
			continue
		var h = r.collider
		var pt: Vector3 = r.position
		var dmg: float = float(w["dmg"])
		if w.get("boom", false):
			_blast(pt, 7.0)
		if h is Human:
			var head_shot: bool = pt.y > (h as Human).global_position.y + 1.4
			(h as Human).hit(dmg * (2.0 if head_shot else 1.0), d, pt, false, float(w.get("sever", 1.0)))
		elif h is Beer:
			(h as Beer).smash()
		elif h is Barrel:
			(h as Barrel).explode()
		elif h is Car:
			(h as Car).shot(pt, d)
		elif h is RigidBody3D:
			if (h as Node).is_in_group("bricks"):
				var bw := (h as Node).get_parent()
				if bw is BrickWall:
					(bw as BrickWall).break_near(pt, 1.6, d * 6.0)
			else:
				(h as RigidBody3D).apply_impulse(d * dmg * 0.15, pt - (h as Node3D).global_position)

func _gravity_fire() -> void:
	if held_h != null and is_instance_valid(held_h):
		held_h.release(-cam.global_transform.basis.z * 14.0)
		held_h = null
		_set_btn_text("grab", "Хват")
		return
	if held != null and is_instance_valid(held):
		held.linear_velocity = -cam.global_transform.basis.z * 28.0
		held = null
		return
	var xf := cam.global_transform
	var q := PhysicsRayQueryParameters3D.create(xf.origin, xf.origin - xf.basis.z * 14.0, 1 | 2 | 4 | 16)
	var r := get_world_3d().direct_space_state.intersect_ray(q)
	if r.is_empty():
		return
	var h = r.collider
	if h is Human:
		(h as Human).grab()
		held_h = h as Human
		held_dist = clampf(xf.origin.distance_to(r.position), 2.5, 7.0)
		return
	if h is RigidBody3D:
		var rb := h as RigidBody3D
		rb.freeze = false
		held = rb
		held_dist = clampf(xf.origin.distance_to(rb.global_position), 2.5, 7.0)

func kick() -> void:
	_kick_anim()
	var f := -player.global_transform.basis.z
	for h in get_tree().get_nodes_in_group("humans"):
		var dv: Vector3 = h.global_position - player.global_position
		dv.y = 0.0
		if dv.length() < 2.4 and dv.normalized().dot(f) > 0.4:
			(h as Human).knock(f * 2.0 + Vector3.UP * 1.2)
	for b in get_tree().get_nodes_in_group("beer"):
		if b.global_position.distance_to(player.global_position) < 2.4:
			(b as Beer).apply_central_impulse(f * 4.0 + Vector3.UP * 2.0)
	for b in get_tree().get_nodes_in_group("barrels"):
		if b.global_position.distance_to(player.global_position) < 2.4:
			(b as Barrel).apply_central_impulse(f * 40.0 + Vector3.UP * 10.0)

func _kick_anim() -> void:
	kick_leg.visible = true
	kick_leg.rotation.x = 0.0
	var tw := create_tween()
	tw.tween_property(kick_leg, "rotation:x", 1.25, 0.12)
	tw.tween_property(kick_leg, "rotation:x", 0.0, 0.2)
	tw.tween_callback(func(): kick_leg.visible = false)

func _drink() -> void:
	if near_beer == null or not is_instance_valid(near_beer):
		return
	near_beer.queue_free()
	near_beer = null
	drunk = 25.0
	_show_toast("Глык-глык... Пиво выпито")

# ---------------- спавн, машины, дрон ----------------
func _spawn_front(dist: float, h: float) -> Vector3:
	var f := -player.global_transform.basis.z
	return player.global_position + f * dist + Vector3(0, h, 0)

func _spawn_car(kind: int) -> void:
	var c := Car.new()
	c.build(kind)
	add_child(c)
	c.global_position = _spawn_front(7.0, 1.2)
	c.rotation.y = yaw

func _enter_car(c: Car) -> void:
	if c == null:
		return
	car = c
	c.occupied = true
	car_yaw = 0.0
	pitch = 0.0
	player.collision_layer = 0
	player.collision_mask = 0
	c.cam.make_current()
	_set_weapon(wi)
	_apply_mode()

func _exit_car() -> void:
	if car == null:
		return
	var c := car
	car = null
	c.occupied = false
	player.global_position = c.global_position + c.global_transform.basis.x * 2.8 + Vector3(0, 0.5, 0)
	player.collision_layer = 8
	player.collision_mask = 1
	yaw = c.rotation.y
	cam.make_current()
	_set_weapon(wi)
	_apply_mode()

func _spawn_beer() -> void:
	var b := Beer.new()
	b.build()
	add_child(b)
	b.global_position = _spawn_front(1.8, 1.3) + Vector3(randf_range(-0.2, 0.2), 0, randf_range(-0.2, 0.2))

func _spawn_barrel(expl: bool) -> void:
	var b := Barrel.new()
	b.build(expl)
	add_child(b)
	b.global_position = _spawn_front(3.0, 1.0)
	b.exploded.connect(_blast.bind(6.0))

func _spawn_drone() -> void:
	if drone != null and is_instance_valid(drone):
		drone.queue_free()
	ctrl = false
	cam.make_current()
	drone = Drone.new()
	drone.build()
	add_child(drone)
	drone.global_position = _spawn_front(3.0, 1.4)
	drone.rotation.y = yaw
	drone.exploded.connect(_on_boom)
	_apply_mode()

func _on_boom(pos: Vector3) -> void:
	_blast(pos, 6.0)
	Fx.burst(self, pos, Color(0.2, 0.2, 0.2), 30, 5.0, 0.2, 1.2)
	drone = null
	ctrl = false
	cam.make_current()
	_set_weapon(wi)
	_apply_mode()

func _toggle_drone() -> void:
	if drone == null or not is_instance_valid(drone):
		return
	ctrl = not ctrl
	if ctrl:
		drone.cam.make_current()
	else:
		cam.make_current()
	_set_weapon(wi)
	_apply_mode()

func _apply_mode() -> void:
	var foot := (not ctrl) and car == null
	weapon_root.visible = foot
	legs.visible = foot
	acro.visible = ctrl
	for k in FOOT_BTNS:
		(btns[k] as Control).visible = foot
	for k in ["up", "down"]:
		(btns[k] as Control).visible = ctrl
	for k in ["brake", "exit"]:
		(btns[k] as Control).visible = car != null
	(btns["drone"] as Control).visible = (drone != null and is_instance_valid(drone)) and car == null
	_set_btn_text("drone", "Выйти из дрона" if ctrl else "Управлять дроном")

# ---------------- HUD ----------------
func _mk_btn(key: String, text: String, r: Rect2, round_: bool = false) -> void:
	var p := Panel.new()
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.91, 0.91, 0.89, 0.85)
	sb.set_border_width_all(3)
	sb.border_color = Color.BLACK
	sb.set_corner_radius_all(int(r.size.x / 2.0) if round_ else 12)
	p.add_theme_stylebox_override("panel", sb)
	p.position = r.position
	p.size = r.size
	p.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud.add_child(p)
	var l := Label.new()
	l.text = text
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	l.add_theme_color_override("font_color", Color.BLACK)
	l.add_theme_font_size_override("font_size", 20)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	p.add_child(l)
	l.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	btns[key] = p

func _set_btn_text(key: String, t: String) -> void:
	if btns.has(key):
		((btns[key] as Control).get_child(0) as Label).text = t

func _label(t: String, size: int, col: Color) -> Label:
	var l := Label.new()
	l.text = t
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", col)
	l.add_theme_color_override("font_outline_color", Color.BLACK)
	l.add_theme_constant_override("outline_size", 6)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud.add_child(l)
	return l

const LENS_SHADER := """shader_type canvas_item;
uniform sampler2D tex : hint_screen_texture, filter_linear_mipmap;
uniform float fish = 0.2;
uniform float rain = 0.0;
float h(vec2 p){ return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
void fragment(){
	vec2 uv = SCREEN_UV;
	vec2 c = uv - 0.5;
	vec2 u = c * (1.0 + fish * dot(c, c) * 2.0) + 0.5;
	vec2 g = u * vec2(14.0, 8.0);
	vec2 id = floor(g);
	vec2 f = fract(g) - 0.5;
	float rnd = h(id);
	float show = step(1.0 - rain * 0.5, rnd);
	float life = fract(TIME * 0.05 + rnd * 7.0);
	vec2 off = vec2(h(id + 3.0) - 0.5, h(id + 7.0) - 0.5) * 0.5;
	float drop = show * smoothstep(0.22, 0.0, length(f - off)) * smoothstep(0.0, 0.1, life) * smoothstep(1.0, 0.7, life);
	u += normalize(f - off + 0.0001) * drop * 0.02;
	vec3 col = texture(tex, u).rgb;
	vec3 bl = (texture(tex, u + vec2(0.004, 0.0)).rgb + texture(tex, u - vec2(0.004, 0.0)).rgb + texture(tex, u + vec2(0.0, 0.004)).rgb + texture(tex, u - vec2(0.0, 0.004)).rgb) * 0.25;
	col = mix(col, bl, rain * 0.5 + drop * 0.4);
	float inside = step(0.0, u.x) * step(u.x, 1.0) * step(0.0, u.y) * step(u.y, 1.0);
	float gr = dot(col, vec3(0.3, 0.59, 0.11));
	col = mix(vec3(gr), col, 0.8);
	col *= mix(0.5, 1.0, smoothstep(0.95, 0.3, distance(uv, vec2(0.5))));
	COLOR = vec4(col * inside, 1.0);
}"""

func _build_hud() -> void:
	if Cfg.bodycam:
		var fx := CanvasLayer.new()
		fx.layer = 1
		add_child(fx)
		var cr := ColorRect.new()
		cr.mouse_filter = Control.MOUSE_FILTER_IGNORE
		var sh := Shader.new()
		sh.code = LENS_SHADER
		lens_mat = ShaderMaterial.new()
		lens_mat.shader = sh
		cr.material = lens_mat
		fx.add_child(cr)
		cr.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	hud = CanvasLayer.new()
	hud.layer = 2
	add_child(hud)
	st_label = _label("", 24, Color.WHITE)
	st_label.position = Vector2(24, 10)
	acro = _label("ACRO", 40, Color(0.6, 0.94, 0.42))
	acro.position = Vector2(S.x / 2.0 - 60.0, 70)
	toast = _label("", 30, Color.WHITE)
	toast.position = Vector2(S.x / 2.0 - 160.0, S.y / 2.0 + 60.0)
	toast.modulate.a = 0.0
	for sz in [Vector2(26, 3), Vector2(3, 26)]:
		var cr2 := ColorRect.new()
		cr2.color = Color(1, 1, 1, 0.9)
		cr2.size = sz
		cr2.position = Vector2(S.x / 2.0, S.y / 2.0) - sz / 2.0
		cr2.mouse_filter = Control.MOUSE_FILTER_IGNORE
		hud.add_child(cr2)
		xh_rects.append(cr2)
	joy_ring = Panel.new()
	var rs := StyleBoxFlat.new()
	rs.bg_color = Color(0, 0, 0, 0.25)
	rs.set_border_width_all(3)
	rs.border_color = Color(0.91, 0.91, 0.89, 0.7)
	rs.set_corner_radius_all(75)
	joy_ring.add_theme_stylebox_override("panel", rs)
	joy_ring.size = Vector2(150, 150)
	joy_ring.position = Vector2(40, S.y - 200)
	joy_ring.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud.add_child(joy_ring)
	joy_center = joy_ring.position + Vector2(75, 75)
	joy_knob = Panel.new()
	var ks := StyleBoxFlat.new()
	ks.bg_color = Color(0.91, 0.91, 0.89, 0.8)
	ks.set_corner_radius_all(30)
	joy_knob.add_theme_stylebox_override("panel", ks)
	joy_knob.size = Vector2(60, 60)
	joy_knob.position = joy_center - Vector2(30, 30)
	joy_knob.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud.add_child(joy_knob)
	_mk_btn("fire", "Огонь", Rect2(S.x - 170, S.y - 190, 130, 130), true)
	_mk_btn("aim", "Прицел", Rect2(S.x - 320, S.y - 130, 130, 70))
	_mk_btn("kick", "Пинок", Rect2(S.x - 320, S.y - 215, 130, 70))
	_mk_btn("finish", "Добить", Rect2(S.x - 490, S.y - 215, 150, 70))
	_mk_btn("grab", "Хват", Rect2(S.x - 320, S.y - 300, 130, 70))
	_mk_btn("weapon", "Пистолет", Rect2(S.x - 190, S.y - 280, 150, 70))
	_mk_btn("attach", "Обвесы", Rect2(S.x - 190, S.y - 360, 150, 70))
	_mk_btn("leanl", "Влево", Rect2(40, S.y - 280, 90, 60))
	_mk_btn("leanr", "Вправо", Rect2(140, S.y - 280, 90, 60))
	_mk_btn("up", "Вверх", Rect2(S.x - 190, S.y - 330, 150, 100))
	_mk_btn("down", "Вниз", Rect2(S.x - 190, S.y - 210, 150, 100))
	_mk_btn("brake", "Тормоз", Rect2(S.x - 190, S.y - 200, 150, 100))
	_mk_btn("exit", "Выйти", Rect2(S.x - 190, S.y - 320, 150, 90))
	_mk_btn("drone", "Управлять дроном", Rect2(S.x / 2.0 - 130, S.y - 100, 260, 70))
	_mk_btn("drink", "Выпить", Rect2(S.x / 2.0 - 90, S.y - 180, 180, 60))
	_mk_btn("enter", "Сесть в машину", Rect2(S.x / 2.0 - 120, S.y - 250, 240, 60))
	_mk_btn("menu", "Меню", Rect2(24, 56, 110, 56))
	_mk_btn("spawn", "Спавн", Rect2(144, 56, 110, 56))
	_build_spawn_panel()
	_build_att_panel()
	if Cfg.bodycam:
		var pc := PanelContainer.new()
		var bs := StyleBoxFlat.new()
		bs.bg_color = Color(0.02, 0.02, 0.03, 0.9)
		bs.set_content_margin_all(8)
		pc.add_theme_stylebox_override("panel", bs)
		pc.mouse_filter = Control.MOUSE_FILTER_IGNORE
		hud.add_child(pc)
		pc.position = Vector2(S.x - 330, 0)
		var hb := HBoxContainer.new()
		hb.add_theme_constant_override("separation", 10)
		hb.mouse_filter = Control.MOUSE_FILTER_IGNORE
		pc.add_child(hb)
		bc_label = Label.new()
		bc_label.add_theme_font_size_override("font_size", 15)
		bc_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
		hb.add_child(bc_label)
		var tr := TextureRect.new()
		tr.texture = load("res://assets/axon.png") as Texture2D
		tr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		tr.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		tr.custom_minimum_size = Vector2(52, 52)
		tr.mouse_filter = Control.MOUSE_FILTER_IGNORE
		hb.add_child(tr)
		# индикатор батареи: всегда 100%
		var bp := PanelContainer.new()
		var bsb := StyleBoxFlat.new()
		bsb.bg_color = Color(0.02, 0.02, 0.03, 0.9)
		bsb.set_content_margin_all(5)
		bp.add_theme_stylebox_override("panel", bsb)
		bp.mouse_filter = Control.MOUSE_FILTER_IGNORE
		hud.add_child(bp)
		bp.position = Vector2(S.x - 190, 76)
		var bh := HBoxContainer.new()
		bh.add_theme_constant_override("separation", 3)
		bh.mouse_filter = Control.MOUSE_FILTER_IGNORE
		bp.add_child(bh)
		var bl := Label.new()
		bl.text = "BAT"
		bl.add_theme_font_size_override("font_size", 14)
		bh.add_child(bl)
		for i in 4:
			var bar := ColorRect.new()
			bar.color = Color(0.3, 0.9, 0.3)
			bar.custom_minimum_size = Vector2(10, 16)
			bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
			bh.add_child(bar)
		var pl := Label.new()
		pl.text = "100%"
		pl.add_theme_font_size_override("font_size", 14)
		bh.add_child(pl)
	_update_stats()

func _build_spawn_panel() -> void:
	spawn_panel = PanelContainer.new()
	spawn_panel.visible = false
	spawn_panel.custom_minimum_size = Vector2(400, 0)
	hud.add_child(spawn_panel)
	spawn_panel.position = Vector2(S.x / 2.0 - 200, S.y / 2.0 - 200)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 8)
	spawn_panel.add_child(vb)
	var t := Label.new()
	t.text = "Спавн"
	t.add_theme_font_size_override("font_size", 30)
	t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vb.add_child(t)
	var tabs := HBoxContainer.new()
	vb.add_child(tabs)
	var names := ["Люди", "Транспорт", "Предметы"]
	for i in 3:
		var tb := Button.new()
		tb.text = names[i]
		tb.custom_minimum_size = Vector2(125, 56)
		tb.pressed.connect(_spawn_tab.bind(i + 1))
		tabs.add_child(tb)
	spawn_items = VBoxContainer.new()
	vb.add_child(spawn_items)
	var cl := Button.new()
	cl.text = "Закрыть"
	cl.custom_minimum_size = Vector2(0, 56)
	cl.pressed.connect(func(): spawn_panel.visible = false)
	vb.add_child(cl)
	_spawn_tab(1)

func _build_att_panel() -> void:
	att_panel = PanelContainer.new()
	att_panel.visible = false
	att_panel.custom_minimum_size = Vector2(340, 0)
	hud.add_child(att_panel)
	att_panel.position = Vector2(S.x / 2.0 - 170, S.y / 2.0 - 170)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 8)
	att_panel.add_child(vb)
	var t := Label.new()
	t.text = "Обвесы"
	t.add_theme_font_size_override("font_size", 30)
	t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vb.add_child(t)
	for key in ["scope", "supp", "laser"]:
		var b := Button.new()
		b.custom_minimum_size = Vector2(0, 60)
		b.add_theme_font_size_override("font_size", 22)
		b.pressed.connect(_toggle_att.bind(key))
		vb.add_child(b)
		att_btns.append(b)
	var cl := Button.new()
	cl.text = "Закрыть"
	cl.custom_minimum_size = Vector2(0, 56)
	cl.pressed.connect(func(): att_panel.visible = false)
	vb.add_child(cl)

func _item(text: String, cb: Callable) -> void:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(0, 64)
	b.add_theme_font_size_override("font_size", 22)
	b.pressed.connect(func():
		cb.call()
		spawn_panel.visible = false)
	spawn_items.add_child(b)

func _spawn_tab(n: int) -> void:
	for c in spawn_items.get_children():
		c.queue_free()
	if n == 1:
		_item("Человек", func(): _spawn_human(_spawn_front(4.0, 0.0)))
	elif n == 2:
		_item("Седан", func(): _spawn_car(0))
		_item("Пикап", func(): _spawn_car(1))
		_item("Дрифт-кар", func(): _spawn_car(2))
		_item("Камикадзе-дрон (бесплатно)", _spawn_drone)
	else:
		_item("Пиво", _spawn_beer)
		_item("Ящик пива (6)", func():
			for i in 6:
				_spawn_beer())
		_item("Бочка взрывная", func(): _spawn_barrel(true))
		_item("Бочка", func(): _spawn_barrel(false))

func _update_stats() -> void:
	if st_label != null:
		st_label.text = "Убийства: %d" % kills

func _bodycam_text() -> String:
	var tz := Time.get_time_zone_from_system()
	var bias: int = int(tz.get("bias", 0))
	var sign_s := "+" if bias >= 0 else "-"
	var ab := absi(bias)
	return "%s %s%02d%02d\nAXON BODY 3 X071088133" % [Time.get_datetime_string_from_system(false, true), sign_s, ab / 60, ab % 60]

# ---------------- ввод ----------------
func _any_panel() -> bool:
	return spawn_panel.visible or att_panel.visible

func _role_at(pos: Vector2) -> String:
	if _any_panel():
		return "ui"
	for k in btns:
		var c := btns[k] as Control
		if c.visible and c.get_global_rect().has_point(pos):
			return k
	if joy_ring.get_global_rect().grow(30.0).has_point(pos):
		return "joy"
	return "look"

func _joy_set(pos: Vector2) -> void:
	joy = ((pos - joy_center) / 75.0).limit_length(1.0)
	joy_knob.position = joy_center - Vector2(30, 30) + joy * 60.0

func _press(role: String, pos: Vector2) -> void:
	match role:
		"fire":
			fire_held = true
			fire_edge = true
		"aim":
			aim_on = not aim_on
		"finish":
			_start_finisher()
		"kick":
			kick_req = true
		"grab":
			_toggle_grab()
		"weapon":
			_set_weapon((wi + 1) % WEAPONS.size())
		"attach":
			_refresh_att()
			att_panel.visible = true
		"leanl":
			lean_l = true
		"leanr":
			lean_r = true
		"spawn":
			spawn_panel.visible = true
		"menu":
			exit_menu.emit()
		"drone":
			_toggle_drone()
		"drink":
			_drink()
		"enter":
			_enter_car(near_car)
		"exit":
			_exit_car()
		"brake":
			brake_held = true
		"up":
			up_held = true
		"down":
			down_held = true
		"joy":
			_joy_set(pos)

func _release(role: String) -> void:
	match role:
		"fire":
			fire_held = false
		"leanl":
			lean_l = false
		"leanr":
			lean_r = false
		"brake":
			brake_held = false
		"up":
			up_held = false
		"down":
			down_held = false
		"joy":
			joy = Vector2.ZERO
			joy_knob.position = joy_center - Vector2(30, 30)

func _input(event: InputEvent) -> void:
	if fin_active:
		return
	if event is InputEventScreenTouch:
		var idx: int = event.index
		if event.pressed:
			var role := _role_at(event.position)
			touches[idx] = role
			_press(role, event.position)
		elif touches.has(idx):
			_release(touches[idx])
			touches.erase(idx)
	elif event is InputEventScreenDrag:
		var role: String = touches.get(event.index, "")
		if role == "joy":
			_joy_set(event.position)
		elif role == "look":
			look_acc += event.relative
			if car != null:
				car_yaw -= event.relative.x * 0.0045
				pitch = clampf(pitch - event.relative.y * 0.0045, -0.6, 0.6)
			else:
				yaw -= event.relative.x * 0.0045
				if not ctrl:
					pitch = clampf(pitch - event.relative.y * 0.0045, -1.4, 1.4)
	elif event is InputEventKey and not event.echo:
		match event.keycode:
			KEY_SPACE:
				fire_held = event.pressed
				if event.pressed:
					fire_edge = true
			KEY_1:
				if event.pressed: _set_weapon(0)
			KEY_2:
				if event.pressed: _set_weapon(1)
			KEY_3:
				if event.pressed: _set_weapon(2)
			KEY_4:
				if event.pressed: _set_weapon(3)
			KEY_E:
				if event.pressed: kick_req = true
			KEY_Q:
				if event.pressed: spawn_panel.visible = not spawn_panel.visible
			KEY_Z:
				lean_l = event.pressed
			KEY_C:
				lean_r = event.pressed
			KEY_F:
				if event.pressed:
					if car != null:
						_exit_car()
					elif near_car != null:
						_enter_car(near_car)
					else:
						_drink()
			KEY_SHIFT:
				aim_on = event.pressed

# ---------------- цикл ----------------
func _process(_delta: float) -> void:
	if bc_label != null:
		bc_label.text = _bodycam_text()

func _lean(delta: float) -> float:
	var dir := (1.0 if lean_r else 0.0) - (1.0 if lean_l else 0.0)
	lean_cur = move_toward(lean_cur, dir, delta * 5.0)
	var allowed := 0.38
	if dir != 0.0:
		var from := player.global_position + Vector3(0, 1.6, 0)
		var q := PhysicsRayQueryParameters3D.create(from, from + player.global_transform.basis.x * dir * 0.62, 1)
		var r := get_world_3d().direct_space_state.intersect_ray(q)
		if not r.is_empty():
			allowed = maxf(0.0, (r.position as Vector3).distance_to(from) - 0.22)
	return lean_cur * allowed

func _update_context() -> void:
	near_beer = null
	near_car = null
	near_victim = null
	var foot := (not ctrl) and car == null
	if foot and not fin_active:
		var f2 := -cam.global_transform.basis.z
		var best := 2.8
		for hh in get_tree().get_nodes_in_group("humans"):
			var hm := hh as Human
			if hm.dead or hm.grabbed:
				continue
			var dv2: Vector3 = hm.global_position + Vector3(0, 1.0, 0) - cam.global_position
			if dv2.length() < best and dv2.normalized().dot(f2) > 0.35:
				best = dv2.length()
				near_victim = hm
	(btns["finish"] as Control).visible = near_victim != null
	if foot:
		var f := -cam.global_transform.basis.z
		for b in get_tree().get_nodes_in_group("beer"):
			var dv: Vector3 = b.global_position - cam.global_position
			if dv.length() < 2.4 and dv.normalized().dot(f) > 0.55:
				near_beer = b
				break
		for c in get_tree().get_nodes_in_group("cars"):
			if c.global_position.distance_to(player.global_position) < 5.5:
				near_car = c
				break
	(btns["drink"] as Control).visible = near_beer != null
	(btns["enter"] as Control).visible = near_car != null

func _physics_process(delta: float) -> void:
	t_acc += delta
	fire_cd -= delta
	if fin_active:
		_fin_step(delta)
		return
	saw_on = wi == SAW and fire_held and car == null and not ctrl
	if saw_on and not saw_snd.playing:
		saw_snd.play()
	elif not saw_on and saw_snd.playing:
		saw_snd.stop()
	weather.update(delta, player.global_position)
	var wet := weather.raining()
	for c in get_tree().get_nodes_in_group("cars"):
		(c as Car).wet = wet and in_mud((c as Node3D).global_position)
	if road_mat != null:
		road_mat.albedo_color = Color(0.4, 0.29, 0.18).lerp(Color(0.2, 0.14, 0.09), weather.intensity)
	if lens_mat != null:
		lens_mat.set_shader_parameter("rain", weather.intensity)
	var kb := Vector2(
		int(Input.is_key_pressed(KEY_D)) - int(Input.is_key_pressed(KEY_A)),
		int(Input.is_key_pressed(KEY_S)) - int(Input.is_key_pressed(KEY_W)))
	var inp := (joy + kb).limit_length(1.0)
	var look := look_acc
	look_acc = Vector2.ZERO
	var lean_off := 0.0
	if car != null and is_instance_valid(car):
		car.drive(-inp.y, inp.x, brake_held, delta)
		player.global_position = car.global_position
		car.cam.rotation = Vector3(pitch, clampf(car_yaw, -1.6, 1.6), 0)
	elif ctrl and drone != null and is_instance_valid(drone):
		var vert := (1.0 if up_held else 0.0) - (1.0 if down_held else 0.0)
		drone.drive(Vector2(inp.x, -inp.y), vert, yaw, delta)
	else:
		player.rotation.y = yaw
		head.rotation.x = pitch
		var fwd := -player.global_transform.basis.z
		var right := player.global_transform.basis.x
		var d := right * inp.x + fwd * (-inp.y)
		player.velocity = Vector3(d.x * 5.0, -4.0, d.z * 5.0)
		player.move_and_slide()
		if fire_edge or (fire_held and bool(WEAPONS[wi]["auto"])):
			shoot()
		if kick_req:
			kick()
		lean_off = _lean(delta)
		_hold_human(delta)
		if held != null:
			if is_instance_valid(held):
				var target := cam.global_position - cam.global_transform.basis.z * held_dist
				held.linear_velocity = ((target - held.global_position) * 12.0).limit_length(40.0)
				held.angular_velocity *= 0.9
			else:
				held = null
	fire_edge = false
	kick_req = false
	_visuals(delta, inp, look, lean_off)
	if saw_on:
		weapon_root.position += Vector3(randf() - 0.5, randf() - 0.5, 0.0) * 0.008
	_update_context()

# инерция оружия, покачивание при ходьбе, наклон, алкоголь, прицел
func _drop_held() -> void:
	if held_h != null and is_instance_valid(held_h):
		held_h.release(Vector3.ZERO)
	held_h = null
	held = null
	_set_btn_text("grab", "Хват")

# Кнопка «Хват»: взять предмет/человека, дёргать, нажать ещё раз, чтобы отпустить
func _toggle_grab() -> void:
	if held != null or held_h != null:
		_drop_held()
		return
	var xf := cam.global_transform
	var q := PhysicsRayQueryParameters3D.create(xf.origin, xf.origin - xf.basis.z * 3.2, 1 | 2 | 4 | 16)
	var r := get_world_3d().direct_space_state.intersect_ray(q)
	if r.is_empty():
		return
	var h = r.collider
	var dist := clampf(xf.origin.distance_to(r.position), 1.1, 2.4)
	if h is Human:
		(h as Human).grab()
		held_h = h as Human
		held_dist = dist + 0.2
		_set_btn_text("grab", "Отпустить")
	elif h is RigidBody3D:
		if (h as RigidBody3D).mass > 80.0:
			_show_toast("Слишком тяжёлое")
			return
		(h as RigidBody3D).freeze = false
		held = h as RigidBody3D
		held_dist = dist
		_set_btn_text("grab", "Отпустить")

func _hold_human(delta: float) -> void:
	if held_h == null:
		return
	if not is_instance_valid(held_h) or held_h.dead:
		held_h = null
		_set_btn_text("grab", "Хват")
		return
	var goal := cam.global_position - cam.global_transform.basis.z * held_dist - Vector3(0, 1.2, 0)
	goal.y = maxf(goal.y, 0.0)
	var old := held_h.global_position
	var np := old.lerp(goal, minf(1.0, 12.0 * delta))
	held_h.shake = (np - old).length() / maxf(delta, 0.001)
	held_h.global_position = np
	var to := cam.global_position - np
	held_h.rotation.y = lerp_angle(held_h.rotation.y, atan2(to.x, to.z), 0.2)

# Бензопила: пока зажат огонь, режет всё впереди
func _saw_tick() -> void:
	var xf := cam.global_transform
	var d := -xf.basis.z
	var q := PhysicsRayQueryParameters3D.create(xf.origin, xf.origin + d * 2.1, 1 | 2 | 4 | 16)
	var r := get_world_3d().direct_space_state.intersect_ray(q)
	_scare(25.0, 5.0)
	if r.is_empty():
		return
	var h = r.collider
	var pt: Vector3 = r.position
	if h is Human:
		(h as Human).hit(float(WEAPONS[SAW]["dmg"]), d, pt, true, 4.0)
		if Cfg.gore > 0:
			Fx.burst(self, pt, Color(0.67, 0.0, 0.06), 10 if Cfg.gore == 1 else 22, 5.0, 0.04, 0.7)
	elif h is Beer:
		(h as Beer).smash()
	elif h is RigidBody3D and (h as RigidBody3D).mass < 200.0:
		(h as RigidBody3D).apply_impulse(d * 2.0, pt - (h as Node3D).global_position)

# «Добить»: короткая сцена от третьего лица с бензопилой
func _start_finisher() -> void:
	if fin_active or near_victim == null or not is_instance_valid(near_victim):
		return
	_drop_held()
	fin_victim = near_victim
	fin_active = true
	fin_t = 0.0
	fin_hit = false
	fin_gib = false
	fin_victim.grab()
	fin_victim.shake = 3.0
	var vp := fin_victim.global_position
	var to := vp - player.global_position
	to.y = 0.0
	fin_dir = to.normalized() if to.length() > 0.01 else -player.global_transform.basis.z
	fin_avatar = Human.new()
	fin_avatar.setup(Color(0.35, 0.2, 0.5))
	fin_avatar.remove_from_group("humans")
	fin_avatar.collision_layer = 0
	fin_avatar.collision_mask = 0
	add_child(fin_avatar)
	fin_avatar.global_position = vp - fin_dir * 1.6
	fin_avatar.rotation.y = atan2(fin_dir.x, fin_dir.z)
	fin_victim.rotation.y = atan2(-fin_dir.x, -fin_dir.z)
	var sw := Guns.build("chainsaw")
	fin_saw = sw["root"] as Node3D
	(fin_avatar.piv["ra"] as Node3D).add_child(fin_saw)
	fin_saw.rotation.x = -PI / 2.0
	fin_saw.position = Vector3(0, -0.6, 0)
	fin_cam = Camera3D.new()
	fin_cam.fov = 60.0
	add_child(fin_cam)
	fin_cam.make_current()
	weapon_root.visible = false
	hud.visible = false
	fire_held = false
	saw_snd.play()

func _fin_step(delta: float) -> void:
	fin_t += delta
	var vok := fin_victim != null and is_instance_valid(fin_victim)
	var arm := fin_avatar.piv["ra"] as Node3D
	(fin_avatar.piv["la"] as Node3D).rotation = Vector3(-1.0, 0.0, 0.3)
	if fin_t < 0.55:
		arm.rotation = arm.rotation.lerp(Vector3(-2.4, 0.0, -0.3), 0.18)
	elif fin_t < 0.8:
		arm.rotation = arm.rotation.lerp(Vector3(-0.4, 0.0, 0.5), 0.45)
	else:
		arm.rotation = arm.rotation.lerp(Vector3(-1.2, 0.0, 0.2), 0.1)
	fin_saw.position = Vector3(randf() - 0.5, randf() - 0.5, 0.0) * 0.01 + Vector3(0, -0.6, 0)
	if vok:
		fin_last = fin_victim.global_position
	if fin_t >= 0.7 and not fin_hit:
		fin_hit = true
		if vok:
			if Cfg.gore > 0:
				Fx.burst(self, fin_victim.global_position + Vector3(0, 1.2, 0), Color(0.67, 0.0, 0.06), 70 if Cfg.gore == 2 else 25, 6.0, 0.05, 1.0)
			fin_v = fin_dir * 4.5 + Vector3.UP * 6.5
			fin_victim.shake = 14.0
			fin_victim.scream()
	if fin_hit and vok and not fin_gib:
		fin_v.y -= 16.0 * delta
		fin_victim.global_position += fin_v * delta
		fin_victim.shake = 14.0
		if Cfg.gore > 0 and fmod(fin_t, 0.06) < delta:
			Fx.burst(self, fin_victim.global_position + Vector3(0, 1.0, 0), Color(0.67, 0.0, 0.06), 3, 2.0, 0.03, 0.5)
		if fin_t >= 1.15:
			fin_gib = true
			var v := fin_victim
			fin_victim = null
			v.die(fin_dir * 2.0 + Vector3.UP * 1.5, true)
	var right := fin_dir.cross(Vector3.UP).normalized()
	var av := fin_avatar.global_position
	var focus := (fin_victim.global_position if vok else fin_last) + Vector3(0, 1.2, 0)
	if fin_t < 0.9:
		fin_cam.global_position = av + right * 1.0 + Vector3(0, 1.9, 0) - fin_dir * 1.3
		fin_cam.look_at(focus, Vector3.UP)
	else:
		fin_cam.global_position = av + fin_dir * 2.4 - right * 1.2 + Vector3(0, 0.4, 0)
		fin_cam.look_at(focus + Vector3(0, 0.5, 0), Vector3.UP)
	if fin_t >= 2.4:
		_end_finisher()

func _end_finisher() -> void:
	fin_active = false
	if fin_avatar != null and is_instance_valid(fin_avatar):
		fin_avatar.queue_free()
	fin_avatar = null
	if fin_victim != null and is_instance_valid(fin_victim):
		fin_victim.release(Vector3.ZERO)
	fin_victim = null
	if fin_cam != null:
		fin_cam.queue_free()
	fin_cam = null
	cam.make_current()
	weapon_root.visible = true
	hud.visible = true
	fire_held = false
	saw_snd.stop()

func _punch_hit() -> void:
	(sfx[wi] as AudioStreamPlayer).play()
	var xf := cam.global_transform
	var d := -xf.basis.z
	var q := PhysicsRayQueryParameters3D.create(xf.origin, xf.origin + d * 2.3, 1 | 2 | 4 | 16)
	var r := get_world_3d().direct_space_state.intersect_ray(q)
	if r.is_empty():
		return
	var h = r.collider
	var pt: Vector3 = r.position
	if h is Human:
		(h as Human).hit(float(WEAPONS[FISTS]["dmg"]), d, pt)
	elif h is Beer:
		(h as Beer).smash()
	elif h is RigidBody3D and (h as RigidBody3D).mass < 200.0:
		(h as RigidBody3D).apply_impulse(d * 6.0, pt - (h as Node3D).global_position)

func _aim_pos() -> Vector3:
	var v: Dictionary = views[wi]
	if v.has("aim"):
		return v["aim_s"] if (v.has("scope") and att[wi]["scope"]) else v["aim"]
	return AIM

# Луч гравипушки: от дула к цели (ярче, если цель можно схватить или она уже в руках)
func _update_beam() -> void:
	var on := wi == 3 and car == null and not ctrl
	beam.visible = on
	if not on:
		return
	var xf := cam.global_transform
	var start: Vector3 = (views[3]["root"] as Node3D).to_global(views[3]["muzzle"] as Vector3)
	var end_p := xf.origin - xf.basis.z * 14.0
	var strong := false
	if held != null and is_instance_valid(held):
		end_p = held.global_position
		strong = true
	elif held_h != null and is_instance_valid(held_h):
		end_p = held_h.global_position + Vector3(0, 1.2, 0)
		strong = true
	else:
		var q := PhysicsRayQueryParameters3D.create(xf.origin, end_p, 1 | 2 | 4 | 16)
		var r := get_world_3d().direct_space_state.intersect_ray(q)
		if not r.is_empty():
			end_p = r.position
			strong = (r.collider is RigidBody3D) or (r.collider is Human)
	var dist := start.distance_to(end_p)
	if dist < 0.05:
		beam.visible = false
		return
	var thick := (1.0 + 0.4 * sin(t_acc * 20.0)) if strong else 0.5
	var cm := beam.mesh as CylinderMesh
	cm.height = dist
	cm.top_radius = 0.012 * thick
	cm.bottom_radius = 0.012 * thick
	beam.global_position = (start + end_p) * 0.5
	var dirv := (end_p - start).normalized()
	beam.look_at(end_p, Vector3.UP if absf(dirv.y) < 0.99 else Vector3.RIGHT)
	beam.rotate_object_local(Vector3.RIGHT, PI / 2.0)
	beam_mat.albedo_color = Color(0.4, 0.9, 1.0, 0.9) if strong else Color(0.5, 0.7, 1.0, 0.25)

func _visuals(delta: float, inp: Vector2, look: Vector2, lean_off: float) -> void:
	var bk := 1.6 if Cfg.bodycam else 1.0
	var foot := (not ctrl) and car == null
	aim_t = move_toward(aim_t, 1.0 if aim_on else 0.0, delta * 8.0)
	if flash_t > 0.0:
		flash_t -= delta
		if flash_t <= 0.0:
			for vv in views:
				if vv.has("flash"):
					(vv["flash"] as Sprite3D).visible = false
	if punch_t >= 0.0 and wi == FISTS:
		punch_t += delta / 0.38
		var fn := (views[FISTS]["fl"] if punch_side == 0 else views[FISTS]["fr"]) as Node3D
		var pp := sin(clampf(punch_t, 0.0, 1.0) * PI)
		fn.position = Vector3(0.0, 0.05 * pp, -0.5 * pp)
		if punch_t >= 0.4 and not punch_done:
			punch_done = true
			_punch_hit()
		if punch_t >= 1.0:
			fn.position = Vector3.ZERO
			punch_t = -1.0
			punch_side = 1 - punch_side
	for xr in xh_rects:
		(xr as Control).modulate.a = lerpf(1.0, 0.25, aim_t)
	if not foot:
		beam.visible = false
		return
	var aim_fov := float(WEAPONS[wi].get("zoom", 32.0 if att[wi]["scope"] else 45.0))
	cam.fov = lerpf(70.0, aim_fov, aim_t)
	if inp.length() > 0.1:
		bob_t += delta * 9.0 * inp.length() * (1.0 - 0.6 * aim_t)
	var lag_t := Vector2(-look.x, look.y) * 0.0009
	lag_t = lag_t.limit_length(0.07)
	lag = lag.lerp(lag_t, minf(1.0, 10.0 * delta))
	recoil = maxf(0.0, recoil - delta * 8.0)
	var base := HIP_C if Cfg.bodycam else HIP_R
	var bobv := Vector3(cos(bob_t * 0.5) * 0.012, absf(sin(bob_t)) * 0.014, 0.0) * bk
	weapon_root.position = base.lerp(_aim_pos(), aim_t) + bobv + Vector3(lag.x, lag.y, 0.0) + Vector3(0, recoil * 0.01, recoil * 0.06)
	var yaw_off := 0.0 if Cfg.bodycam else 0.07 * (1.0 - aim_t)
	weapon_root.rotation = Vector3(recoil * 0.05, yaw_off, -lag.x * 3.0)
	flash.light_energy = 3.0 if recoil > 0.8 else 0.0
	head.position = Vector3(lean_off, 1.6 + sin(bob_t) * 0.025 * bk, 0)
	var sway := 0.0
	if drunk > 0.0:
		drunk -= delta
		var k := clampf(drunk / 6.0, 0.0, 1.0)
		sway = sin(t_acc * 1.7) * 0.07 * k
		cam.fov += sin(t_acc * 0.9) * 4.0 * k
	head.rotation.z = -lean_cur * 0.22 + sway
	_update_beam()
