class_name Weapons
extends RefCounted
# Детальные модели оружия, собранные из примитивов (без Sketchfab).
# Дуло смотрит в -Z. 0 пистолет, 1 автомат, 2 дробовик, 3 грав-пушка.

const METAL := Color(0.11, 0.11, 0.12)
const STEEL := Color(0.27, 0.28, 0.3)
const WOOD := Color(0.42, 0.22, 0.09)
const POLY := Color(0.07, 0.07, 0.08)
const SKIN := Color(0.88, 0.69, 0.5)
const SLEEVE := Color(0.15, 0.17, 0.2)
const SCALES := [1.0, 0.78, 0.75, 1.0]
# Y верхней планки и Z для коллиматора / рукоятки по оружию
const TOP_Y := [0.05, 0.065, 0.08, 0.06]
const DOT_Z := [-0.02, -0.12, -0.05, -0.05]
const GRIP_Z := [0.0, -0.3, -0.3, 0.0]

static func _mat(c: Color, glow: bool = false) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	if glow:
		m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	return m

static func box(p: Node3D, size: Vector3, pos: Vector3, col: Color, rot: Vector3 = Vector3.ZERO, glow: bool = false) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	mi.material_override = _mat(col, glow)
	mi.position = pos
	mi.rotation = rot
	p.add_child(mi)
	return mi

# цилиндр вдоль оси Z
static func cyl(p: Node3D, r: float, length: float, pos: Vector3, col: Color, glow: bool = false) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = r
	cm.bottom_radius = r
	cm.height = length
	mi.mesh = cm
	mi.material_override = _mat(col, glow)
	mi.position = pos
	mi.rotation = Vector3(PI / 2.0, 0, 0)
	p.add_child(mi)
	return mi

static func build(i: int, att: Dictionary) -> Node3D:
	var r := Node3D.new()
	var muzzle := Vector3.ZERO
	match i:
		0:
			box(r, Vector3(0.03, 0.035, 0.2), Vector3(0, 0.02, -0.03), STEEL)            # затвор
			box(r, Vector3(0.028, 0.02, 0.16), Vector3(0, -0.005, -0.01), POLY)          # рама
			cyl(r, 0.008, 0.04, Vector3(0, 0.02, -0.15), METAL)                           # ствол
			box(r, Vector3(0.03, 0.1, 0.045), Vector3(0, -0.06, 0.06), POLY, Vector3(0.2, 0, 0))   # рукоять
			box(r, Vector3(0.024, 0.07, 0.034), Vector3(0, -0.115, 0.075), METAL, Vector3(0.2, 0, 0))  # магазин
			box(r, Vector3(0.01, 0.012, 0.07), Vector3(0, -0.035, 0.0), POLY)             # скоба
			box(r, Vector3(0.008, 0.012, 0.01), Vector3(0, 0.045, -0.12), METAL)          # мушка
			box(r, Vector3(0.022, 0.012, 0.01), Vector3(0, 0.045, 0.06), METAL)           # целик
			muzzle = Vector3(0, 0.02, -0.17)
		1:
			box(r, Vector3(0.05, 0.065, 0.34), Vector3(0, 0, 0), METAL)                   # ствольная коробка
			box(r, Vector3(0.045, 0.02, 0.3), Vector3(0, 0.04, 0), STEEL)                 # крышка
			cyl(r, 0.011, 0.42, Vector3(0, 0.012, -0.38), STEEL)                          # ствол
			cyl(r, 0.012, 0.25, Vector3(0, 0.045, -0.3), STEEL)                           # газовая трубка
			box(r, Vector3(0.052, 0.045, 0.22), Vector3(0, -0.005, -0.27), WOOD)          # цевьё
			box(r, Vector3(0.008, 0.03, 0.008), Vector3(0, 0.05, -0.52), METAL)           # мушка
			cyl(r, 0.016, 0.05, Vector3(0, 0.012, -0.6), METAL)                           # дульный тормоз
			box(r, Vector3(0.02, 0.015, 0.03), Vector3(0, 0.055, -0.1), METAL)            # целик
			box(r, Vector3(0.04, 0.12, 0.07), Vector3(0, -0.09, -0.07), METAL, Vector3(0.1, 0, 0))     # магазин верх
			box(r, Vector3(0.04, 0.1, 0.07), Vector3(0, -0.185, -0.1), METAL, Vector3(0.35, 0, 0))     # магазин низ
			box(r, Vector3(0.035, 0.1, 0.05), Vector3(0, -0.085, 0.12), WOOD, Vector3(-0.35, 0, 0))    # рукоять
			box(r, Vector3(0.04, 0.08, 0.28), Vector3(0, -0.02, 0.32), WOOD, Vector3(0.08, 0, 0))      # приклад
			box(r, Vector3(0.042, 0.1, 0.02), Vector3(0, -0.025, 0.47), METAL)                         # затыльник
			muzzle = Vector3(0, 0.012, -0.63)
		2:
			cyl(r, 0.014, 0.62, Vector3(0, 0.025, -0.35), METAL)                          # ствол
			cyl(r, 0.012, 0.5, Vector3(0, -0.005, -0.3), STEEL)                           # трубчатый магазин
			box(r, Vector3(0.05, 0.075, 0.26), Vector3(0, 0, 0), METAL)                   # ствольная коробка
			box(r, Vector3(0.055, 0.05, 0.2), Vector3(0, -0.01, -0.28), WOOD)             # цевьё
			box(r, Vector3(0.008, 0.012, 0.008), Vector3(0, 0.045, -0.64), STEEL)         # мушка
			box(r, Vector3(0.052, 0.02, 0.08), Vector3(0, 0.02, 0.0), POLY)               # окно выброса
			box(r, Vector3(0.045, 0.1, 0.3), Vector3(0, -0.03, 0.28), WOOD, Vector3(0.15, 0, 0))   # приклад
			box(r, Vector3(0.046, 0.11, 0.025), Vector3(0, -0.045, 0.44), POLY)           # затыльник
			box(r, Vector3(0.01, 0.02, 0.08), Vector3(0, -0.045, 0.05), POLY)             # скоба
			box(r, Vector3(0.03, 0.07, 0.04), Vector3(0, -0.07, 0.1), WOOD, Vector3(-0.3, 0, 0))   # рукоять
			for k in 3:                                                                   # патроны сбоку
				cyl(r, 0.01, 0.05, Vector3(0.03, -0.01, -0.02 + k * 0.045), Color(0.75, 0.1, 0.1))
			muzzle = Vector3(0, 0.025, -0.66)
		_:
			box(r, Vector3(0.07, 0.08, 0.3), Vector3(0, 0, 0), Color(0.12, 0.16, 0.2))
			cyl(r, 0.05, 0.04, Vector3(0, 0, -0.2), Color(0.1, 0.6, 1.0), true)
			box(r, Vector3(0.01, 0.01, 0.15), Vector3(-0.04, 0, -0.28), Color(0.1, 0.6, 1.0), Vector3.ZERO, true)
			box(r, Vector3(0.01, 0.01, 0.15), Vector3(0.04, 0, -0.28), Color(0.1, 0.6, 1.0), Vector3.ZERO, true)
			cyl(r, 0.02, 0.1, Vector3(0, 0, -0.08), Color(1.0, 0.5, 0.1), true)
			box(r, Vector3(0.04, 0.1, 0.05), Vector3(0, -0.08, 0.08), POLY, Vector3(-0.25, 0, 0))
			muzzle = Vector3(0, 0, -0.35)
	# ----- обвесы -----
	if i < 3:
		if att.get("sup", false):
			cyl(r, 0.022, 0.2, muzzle + Vector3(0, 0, -0.1), POLY)
			muzzle += Vector3(0, 0, -0.2)
		if att.get("dot", false):
			var ty: float = TOP_Y[i]
			var dz: float = DOT_Z[i]
			box(r, Vector3(0.03, 0.012, 0.06), Vector3(0, ty, dz), METAL)
			box(r, Vector3(0.034, 0.04, 0.05), Vector3(0, ty + 0.026, dz + 0.01), METAL)
			box(r, Vector3(0.024, 0.024, 0.004), Vector3(0, ty + 0.028, dz - 0.016), Color(1.0, 0.1, 0.1), Vector3.ZERO, true)
		if att.get("laser", false):
			var ly: float = muzzle.y - 0.03
			box(r, Vector3(0.02, 0.02, 0.05), Vector3(0, ly, muzzle.z + 0.12), METAL)
			box(r, Vector3(0.003, 0.003, 14.0), Vector3(0, ly, muzzle.z - 7.0), Color(1.0, 0.05, 0.05), Vector3.ZERO, true)
		if att.get("grip", false) and i > 0:
			box(r, Vector3(0.025, 0.08, 0.03), Vector3(0, -0.07, GRIP_Z[i]), POLY, Vector3(0.1, 0, 0))
	r.scale = Vector3.ONE * float(SCALES[i])
	r.set_meta("muzzle", muzzle * float(SCALES[i]))
	return r

# Руки (в координатах слота, уже с учётом масштаба оружия)
static func hands(i: int, sc: float) -> Node3D:
	var h := Node3D.new()
	var rg: Array = [Vector3(0, -0.07, 0.06), Vector3(0, -0.09, 0.12), Vector3(0, -0.075, 0.1), Vector3(0, -0.07, 0.08)]
	var lf: Array = [Vector3(-0.02, -0.115, 0.07), Vector3(0, -0.045, -0.28), Vector3(0, -0.04, -0.28), Vector3(0, -0.02, -0.1)]
	var rp: Vector3 = (rg[i] as Vector3) * sc
	var lp: Vector3 = (lf[i] as Vector3) * sc
	box(h, Vector3(0.06, 0.06, 0.09), rp, SKIN)
	box(h, Vector3(0.07, 0.07, 0.4), rp + Vector3(0.03, -0.12, 0.27), SLEEVE, Vector3(-0.45, -0.08, 0))
	box(h, Vector3(0.06, 0.05, 0.09), lp, SKIN)
	box(h, Vector3(0.07, 0.07, 0.4), lp + Vector3(-0.07, -0.12, 0.27), SLEEVE, Vector3(-0.4, 0.28, 0))
	return h

# Нога: пивот в бедре, вниз по -Y (для пинка и для ног на земле)
static func leg() -> Node3D:
	var p := Node3D.new()
	var pants := Color(0.16, 0.2, 0.31)
	box(p, Vector3(0.17, 0.47, 0.17), Vector3(0, -0.235, 0), pants)
	box(p, Vector3(0.15, 0.45, 0.15), Vector3(0, -0.69, 0), pants)
	box(p, Vector3(0.17, 0.1, 0.3), Vector3(0, -0.94, -0.07), Color(0.06, 0.06, 0.07))
	return p
